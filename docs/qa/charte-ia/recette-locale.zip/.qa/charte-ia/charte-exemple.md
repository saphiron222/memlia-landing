# Charte IA du cabinet

Trame non officielle — proposition à relire et à faire adopter par le cabinet. Elle ne remplace pas les ressources de l’Ordre et ne certifie aucune conformité. Aucun usage sur dossier réel n’est autorisé par ce document.

## Objet et périmètre

Cette proposition organise une préparation de travail. L’IA prépare ; le cabinet vérifie, saisit et décide. Décision d’adoption : à documenter avant mise en pratique.

## Usages retenus

- Relance de pièces : préparer un brouillon sur un dossier fictif ; vérifier les pièces demandées et le destinataire avant tout envoi humain.

- Synthèse de documents fictifs : préparer une synthèse ; comparer chaque point aux documents sources et signaler toute incertitude.

Tout autre usage reste hors périmètre jusqu’à une nouvelle décision documentée du cabinet.

## Données et outils

Uniquement des données fictives créées pour les essais ; aucune copie d’un dossier réel.

Les données clients, personnelles, confidentielles et les fichiers de dossiers réels sont exclus. Les dossiers réels nécessitent un cadrage distinct ; cette trame ne les autorise pas.

Outils retenus (description générique) : Environnement de démonstration.

Avant de retenir un outil, vérifier les accès, les conditions de traitement, la réutilisation des entrées, la conservation et les paramètres. Un point non vérifié suspend son usage.

## Responsabilités et validation

Responsable des usages : à compléter.

Rôle de validation : Responsable de pôle.

Chaque résultat est relu par le rôle de validation avant utilisation, y compris en interne.

Comparer les sorties aux sources, relever les erreurs et ne jamais présenter une réponse générée comme une référence vérifiée. Aucune écriture, correction, décision ou transmission automatique n’est prévue.

## Incident et arrêt

Arrêter l’usage si une donnée hors périmètre est détectée, si une réponse paraît incertaine ou si une règle se contredit. Alerter le responsable des usages sans recopier de données sensibles dans le signalement ; faire décider les mesures et la reprise par le cabinet.

## Formation et essais

Formation prévue : Atelier sur cas fictif.

Faire pratiquer les usages retenus sur des cas fictifs, y compris un cas qui doit être arrêté. Documenter le contrôle attendu et le rôle chargé de la relecture.

## Révision et arbitrages

Fréquence de relecture : mensuelle.

Prochaine relecture : 2026-12-01.

Revoir le périmètre après un nouvel outil, un incident ou un changement de pratique. Documenter les décisions et informer l’équipe avant reprise.

Points restant à décider :

- [ ] Désigner le rôle responsable des usages.
