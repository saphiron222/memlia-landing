(function () {
  'use strict';
  if (window.__f456Curseur) { return; }
  window.__f456Curseur = true;
  var mq = window.matchMedia;
  if (!mq || !mq('(hover: hover) and (pointer: fine)').matches) { return; }
  if (mq('(prefers-reduced-motion: reduce)').matches) { return; }

  var OR = '255,226,160', PI = Math.PI;
  var R_LUEUR = 300, R_MAIN = 300, DENSITE = 22000, MIN = 10, MAX = 80, MAX_VIVES = 16, PAS_TRACE = 76;
  var root = document.documentElement, layers = [];
  var tx = -1e4, ty = -1e4, x = tx, y = ty, mvx = 0, mvy = 0, dernierMouv = -1e4, chemin = 0;
  var souris = false, lueur = 0, premiere = true, raf = 0, tPrec = 0, n = 0;
  var dpr = Math.min(window.devicePixelRatio || 1, 1.5);

  function rgb(c) {
    var m = c && c.match(/[\d.]+/g);
    if (!m || m.length < 3) { return null; }
    if (m.length > 3 && parseFloat(m[3]) < 0.6) { return null; }
    return [+m[0], +m[1], +m[2]];
  }
  /* L'élément qui peint réellement le fond visible derrière un bloc (on remonte tant que c'est
     transparent). Un fond en image arrête la recherche : on n'y dessine rien. */
  function peintre(el) {
    for (; el && el.nodeType === 1; el = el.parentElement) {
      var s = getComputedStyle(el);
      if (s.backgroundImage && s.backgroundImage.indexOf('url(') >= 0) { return null; }
      var c = rgb(s.backgroundColor);
      if (c) { return { el: el, c: c, s: s }; }
    }
    return null;
  }
  function bleuNuit(c) {
    var l = (0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]) / 255;
    return l < 0.32 && c[2] >= c[0] + 20;
  }

  /* Pinceaux pré-dessinés : le rendu n'est ensuite que des drawImage. */
  function pinceau(taille, arrets) {
    var c = document.createElement('canvas');
    c.width = c.height = taille;
    var g = c.getContext('2d'), r = taille / 2, d = g.createRadialGradient(r, r, 0, r, r, r);
    for (var i = 0; i < arrets.length; i++) { d.addColorStop(arrets[i][0], 'rgba(' + OR + ',' + arrets[i][1] + ')'); }
    g.fillStyle = d;
    g.fillRect(0, 0, taille, taille);
    return c;
  }
  /* Une étoile à quatre branches aux flancs creusés, sur un petit halo. */
  function etoile(taille) {
    var c = pinceau(taille, [[0, 0.45], [0.35, 0.1], [1, 0]]), g = c.getContext('2d'), r = taille / 2;
    g.beginPath();
    g.moveTo(r, 1);
    g.quadraticCurveTo(r, r, taille - 1, r);
    g.quadraticCurveTo(r, r, r, taille - 1);
    g.quadraticCurveTo(r, r, 1, r);
    g.quadraticCurveTo(r, r, r, 1);
    g.closePath();
    g.fillStyle = 'rgba(255,236,180,0.95)';
    g.fill();
    return c;
  }
  var COEUR = pinceau(32, [[0, 1], [0.4, 0.95], [0.7, 0.35], [1, 0]]);
  var HALO = pinceau(128, [[0, 0.55], [0.35, 0.16], [1, 0]]);
  var BOKEH = pinceau(256, [[0, 0.1], [0.5, 0.045], [1, 0]]);
  var LUEUR = pinceau(256, [[0, 0.17], [0.35, 0.065], [1, 0]]);
  var ETOILE = etoile(64);

  /* Positions dans l'espace de l'hôte (y compris hors de la fenêtre) : L.off = décalage du canvas
     le long de l'hôte, L.ch = hauteur du canvas (au plus la fenêtre). */
  function etincelle(L, bas) {
    return { x: Math.random() * L.cw, y: L.off + (bas ? L.ch + 10 : Math.random() * L.ch),
      r: 0.9 + Math.random() * 1.6, a: 0.45 + Math.random() * 0.45, vy: -(7 + Math.random() * 16),
      f: 0.6 + Math.random() * 0.9, ph: Math.random() * 6.2832, ax: 0, ay: 0, vie: bas ? 0 : 1, lit: 0 };
  }
  function bokeh(L, bas) {
    var s = 110 + Math.random() * 130;
    return { x: Math.random() * L.cw, y: L.off + (bas ? L.ch + s / 2 : Math.random() * L.ch), s: s,
      a: 0.6 + Math.random() * 0.4, vx: (Math.random() - 0.5) * 6, vy: -(1.5 + Math.random() * 3), vie: bas ? 0 : 1 };
  }
  /* Une étoile vive : naît, grandit, tourne un peu, s'éteint. s = demi-taille en px. */
  function vive(L, hx, hy, s, dur, vx, vy) {
    if (L.v.length >= MAX_VIVES) { return; }
    L.v.push({ x: hx, y: hy, s: s, dur: dur, t: 0, vx: vx, vy: vy, rot: Math.random() * PI, vr: (Math.random() - 0.5) * 2 });
  }
  /* Fait naître des étoiles vives sous un point de la fenêtre, dans chaque zone qui le contient. */
  function semer(px, py, nb, vitesse, smin, smax) {
    for (var i = 0; i < layers.length; i++) {
      var L = layers[i], r = L.r;
      if (!r) { continue; }
      var hx = px - r.left, hy = py - r.top;
      if (hx < 0 || hx > L.cw || hy < L.off || hy > L.off + L.ch) { continue; }
      for (var j = 0; j < nb; j++) {
        var a = Math.random() * 2 * PI, v = vitesse * (0.4 + Math.random() * 0.6);
        vive(L, hx + (Math.random() - 0.5) * 28, hy + (Math.random() - 0.5) * 28, smin + Math.random() * (smax - smin),
          0.55 + Math.random() * 0.5, Math.cos(a) * v, Math.sin(a) * v - 18 - vitesse * 0.3);
      }
    }
  }
  function dimensionner(L) {
    var r = L.d.getBoundingClientRect(), cw = Math.round(r.width), hh = Math.round(r.height), ch = Math.min(hh, window.innerHeight);
    if (cw === L.cw && ch === L.ch && hh === L.hh) { return; }
    L.cw = cw; L.ch = ch; L.hh = hh;
    L.c.width = Math.round(cw * dpr);
    L.c.height = Math.round(ch * dpr);
    L.c.style.width = cw + 'px';
    L.c.style.height = ch + 'px';
    L.g.setTransform(dpr, 0, 0, dpr, 0, 0);
    L.off = L.fixe ? 0 : Math.max(0, Math.min(hh - ch, Math.round(-r.top)));
    L.c.style.transform = 'translate3d(0,' + L.off + 'px,0)';
    var k = Math.max(MIN, Math.min(MAX, Math.round(cw * ch / DENSITE)));
    L.p = []; L.b = []; L.v = []; L.ef = null;
    for (var i = 0; i < k; i++) { L.p.push(etincelle(L, false)); }
    if (ch >= 300) { for (i = 0; i < 4; i++) { L.b.push(bokeh(L, false)); } }
  }
  function creer(host, devant, classe) {
    if (host.__f456gl) { return; }
    host.__f456gl = true;
    var d = document.createElement('div');
    d.className = 'f456-gl' + (classe ? ' ' + classe : '');
    d.setAttribute('aria-hidden', 'true');
    var c = document.createElement('canvas');
    d.appendChild(c);
    if (classe !== 'f456-fx' && getComputedStyle(host).position === 'static') { host.style.position = 'relative'; }
    host.insertBefore(d, devant || host.firstChild);
    var L = { d: d, c: c, g: c.getContext('2d'), fixe: classe === 'f456-fx', r: null, cw: 0, ch: 0, hh: 0, off: 0,
      p: [], b: [], v: [], ef: null, tw: Math.random(), tw2: 0, prochaine: performance.now() + 4000 + Math.random() * 5000 };
    dimensionner(L);
    layers.push(L);
  }
  function init() {
    var exclus = '.elementor-location-footer, .elementor-location-popup, [data-elementor-type="popup"], .elementor-sticky__spacer, .f456-no-glow';
    [].forEach.call(document.querySelectorAll('.elementor-top-section, .elementor > .e-con'), function (s) {
      if (s.closest(exclus)) { return; }
      if (s.offsetHeight < 40 || s.offsetWidth < 200) { return; }
      var p = peintre(s);
      if (!p || !bleuNuit(p.c)) { return; }
      if (p.el === s) {
        /* La section porte son fond : calque juste avant son contenu (qui, positionné, passe devant). */
        creer(s, s.querySelector(':scope > .elementor-container'), '');
      } else if (p.el === document.body || p.el === root) {
        /* Fond de page : calque fixe, sous tout le reste. */
        creer(document.body, null, 'f456-fx');
      } else {
        /* Conteneur commun (main) : le calque se glisse juste au-dessus de son fond (z-index -1) et
           sous tout son contenu, positionné ou non — l'hôte doit former son propre contexte
           d'empilement ; s'il ne le fait pas déjà, isolation:isolate le lui donne sans rien déplacer. */
        sousTout(p.el);
      }
    });
    /* Encarts d'appel à l'action en dégradé bleu, posés sur une section claire. */
    [].forEach.call(document.querySelectorAll('.rbx .cta, .hc .cta'), function (s) {
      if (!s.closest(exclus)) { sousTout(s); }
    });
  }
  function sousTout(host) {
    if (host.__f456gl) { return; }
    var s = getComputedStyle(host);
    if (s.isolation !== 'isolate' && !(s.position !== 'static' && s.zIndex !== 'auto')) { host.style.isolation = 'isolate'; }
    creer(host, null, 'f456-bk');
  }

  function rendre(L, dt, now) {
    var r = L.d.getBoundingClientRect(), vh = window.innerHeight;
    L.r = r;
    if (r.width === 0 || r.bottom < 0 || r.top > vh) { return false; }
    if (Math.round(r.width) !== L.cw || Math.round(r.height) !== L.hh) { dimensionner(L); }
    var off = L.fixe ? 0 : Math.max(0, Math.min(L.hh - L.ch, Math.round(-r.top)));
    if (off !== L.off) { L.off = off; L.c.style.transform = 'translate3d(0,' + off + 'px,0)'; }
    var g = L.g, cw = L.cw, ch = L.ch, i, p, s, cy, f, k, e;
    var mx = x - r.left, my = y - r.top - off;    /* la lueur, en retard sur la souris */
    var sx = tx - r.left, sy = ty - r.top - off;  /* le pointeur réel, pour les étincelles */
    g.clearRect(0, 0, cw, ch);
    g.globalCompositeOperation = 'lighter';
    /* Profondeur : grandes taches floues, presque immobiles. */
    for (i = 0; i < L.b.length; i++) {
      p = L.b[i];
      p.x += p.vx * dt; p.y += p.vy * dt; p.vie = Math.min(1, p.vie + dt / 3);
      cy = p.y - off; s = p.s;
      if (cy < -s || cy > ch + s || p.x < -s || p.x > cw + s) { L.b[i] = p = bokeh(L, true); cy = p.y - off; s = p.s; }
      g.globalAlpha = p.a * p.vie;
      g.drawImage(BOKEH, p.x - s / 2, cy - s / 2, s, s);
    }
    /* La lueur qui suit la souris. */
    if (lueur > 0.01) {
      g.globalAlpha = lueur;
      g.drawImage(LUEUR, mx - R_LUEUR, my - R_LUEUR, R_LUEUR * 2, R_LUEUR * 2);
    }
    /* Les étincelles qui montent. */
    for (i = 0; i < L.p.length; i++) {
      p = L.p[i];
      p.vie = Math.min(1, p.vie + dt / 1.5);
      cy = p.y - off; f = 0;
      if (souris) {
        var dx = sx - p.x, dy = sy - cy, d = Math.sqrt(dx * dx + dy * dy);
        if (d < R_MAIN) {
          /* Près de la souris : attirance douce, lente rotation, un peu de hauteur, et le souffle
             d'un mouvement vif. Au centre même, plus d'attirance (sinon elles vibrent). */
          f = 1 - d / R_MAIN;
          var ux = dx / (d + 1), uy = dy / (d + 1), pres = d < 50 ? d / 50 : 1;
          p.ax += ((ux * 70 - uy * 30) * pres + mvx * 0.35) * f * dt;
          p.ay += ((uy * 70 + ux * 30) * pres - 40 + mvy * 0.35) * f * dt;
        }
      }
      p.lit = f;
      k = Math.exp(-1.6 * dt);
      p.ax *= k; p.ay *= k;
      p.x += (p.ax + Math.sin(now * 0.0007 * p.f + p.ph) * 6) * dt;
      p.y += (p.vy + p.ay) * dt;
      cy = p.y - off;
      if (cy < -30 || cy > ch + 30 || p.x < -30 || p.x > cw + 30) {
        L.p[i] = p = etincelle(L, cy < -30); p.vie = 0; cy = p.y - off; f = 0;
      }
      var a = Math.min(1, p.a * (0.55 + 0.45 * Math.sin(now * 0.002 * p.f + p.ph)) + f * f * 0.7) * p.vie;
      s = p.r * 2.8 * (1 + f * 0.8);
      g.globalAlpha = a;
      g.drawImage(COEUR, p.x - s / 2, cy - s / 2, s, s);
      if (f > 0.02) {
        s = 10 + p.r * 14 * f;
        g.globalAlpha = f * 0.8 * p.vie;
        g.drawImage(HALO, p.x - s / 2, cy - s / 2, s, s);
      }
    }
    /* De temps en temps, une étincelle pétille ; près de la souris, bien plus souvent. */
    L.tw -= dt; L.tw2 -= dt;
    if (L.tw <= 0 && L.p.length) {
      L.tw = 0.7 + Math.random() * 1.3;
      p = L.p[(Math.random() * L.p.length) | 0];
      if (p.vie > 0.5) { vive(L, p.x, p.y, 4 + Math.random() * 3, 0.8 + Math.random() * 0.4, 0, p.vy); }
    }
    if (false && L.tw2 <= 0 && souris) {
      L.tw2 = 0.25 + Math.random() * 0.35;
      var pres2 = [];
      for (i = 0; i < L.p.length; i++) { if (L.p[i].lit > 0.3 && L.p[i].vie > 0.5) { pres2.push(L.p[i]); } }
      if (pres2.length) { p = pres2[(Math.random() * pres2.length) | 0]; vive(L, p.x, p.y, 3.5 + Math.random() * 3.5, 0.6 + Math.random() * 0.4, 0, p.vy - 10); }
    }
    /* Les étoiles vives. */
    for (i = L.v.length - 1; i >= 0; i--) {
      p = L.v[i];
      p.t += dt / p.dur;
      if (p.t >= 1) { L.v.splice(i, 1); continue; }
      k = Math.exp(-2.5 * dt);
      p.vx *= k; p.vy *= k;
      p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.vr * dt;
      e = Math.sin(PI * p.t);
      s = p.s * (0.35 + 0.65 * e);
      g.save();
      g.translate(p.x, p.y - off);
      g.rotate(p.rot);
      g.globalAlpha = e;
      g.drawImage(ETOILE, -s, -s, s * 2, s * 2);
      g.restore();
    }
    /* L'étoile filante (dans l'espace du canvas : elle traverse ce qu'on voit). */
    if (cw >= 500 && ch >= 300) {
      if (!L.ef) {
        if (now >= L.prochaine) {
          var sens = Math.random() < 0.5 ? 1 : -1, ang = 0.38 + Math.random() * 0.3;
          L.ef = { x: cw * (0.15 + Math.random() * 0.7), y: ch * (0.05 + Math.random() * 0.4), dx: Math.cos(ang) * sens, dy: Math.sin(ang),
            len: Math.max(220, Math.min(520, cw * (0.25 + Math.random() * 0.15))), t: 0, dur: 0.8 + Math.random() * 0.3 };
          L.prochaine = now + 10000 + Math.random() * 10000;
        }
      } else {
        p = L.ef;
        p.t += dt / p.dur;
        if (p.t >= 1) { L.ef = null; }
        else {
          e = Math.sin(PI * p.t);
          var hx = p.x + p.dx * p.len * p.t, hy = p.y + p.dy * p.len * p.t, tl = 150 * (0.3 + 0.7 * e);
          var lg = g.createLinearGradient(hx, hy, hx - p.dx * tl, hy - p.dy * tl);
          lg.addColorStop(0, 'rgba(' + OR + ',' + (0.85 * e).toFixed(3) + ')');
          lg.addColorStop(1, 'rgba(' + OR + ',0)');
          g.globalAlpha = 1; g.strokeStyle = lg; g.lineWidth = 1.6; g.lineCap = 'round';
          g.beginPath(); g.moveTo(hx, hy); g.lineTo(hx - p.dx * tl, hy - p.dy * tl); g.stroke();
          g.globalAlpha = e;
          g.drawImage(HALO, hx - 14, hy - 14, 28, 28);
          g.drawImage(COEUR, hx - 3, hy - 3, 6, 6);
        }
      }
    }
    g.globalAlpha = 1;
    g.globalCompositeOperation = 'source-over';
    return true;
  }

  function boucle(now) {
    raf = 0; n++;
    /* Souris immobile depuis 2 s : une image sur deux suffit. */
    if (now - dernierMouv > 2000 && (n & 1)) { raf = requestAnimationFrame(boucle); return; }
    var dt = Math.min(0.05, Math.max(0, (now - tPrec) / 1000));
    tPrec = now;
    var l = Math.min(1, dt * 7);
    x += (tx - x) * l; y += (ty - y) * l;
    lueur += ((souris ? 1 : 0) - lueur) * Math.min(1, dt * 4);
    var k = Math.exp(-5 * dt);
    mvx *= k; mvy *= k;
    var actif = false;
    for (var i = 0; i < layers.length; i++) { if (rendre(layers[i], dt, now)) { actif = true; } }
    if (premiere) { premiere = false; root.classList.add('f456-on'); }
    /* Plus aucune zone bleue à l'écran : on s'arrête ; le défilement ou la souris relancent. */
    if (actif) { raf = requestAnimationFrame(boucle); }
  }
  function relancer() {
    if (!raf) { tPrec = performance.now(); raf = requestAnimationFrame(boucle); }
  }

  function demarrer() {
    init();
    /* Blocs affichés après le chargement (onglets, contenus différés) : on repasse. */
    setTimeout(function () { init(); relancer(); }, 2500);
    var t = 0;
    window.addEventListener('resize', function () {
      clearTimeout(t);
      t = setTimeout(function () { for (var i = 0; i < layers.length; i++) { dimensionner(layers[i]); } init(); relancer(); }, 300);
    }, { passive: true });
    window.addEventListener('pointermove', function (e) {
      if (e.pointerType && e.pointerType !== 'mouse') { return; }
      var now = performance.now(), d = (now - dernierMouv) / 1000;
      if (souris && d < 0.2) {
        if (d > 0.004) {
          mvx = Math.max(-3000, Math.min(3000, (e.clientX - tx) / d));
          mvy = Math.max(-3000, Math.min(3000, (e.clientY - ty) / d));
        }
        chemin = Math.min(PAS_TRACE * 3, chemin + Math.abs(e.clientX - tx) + Math.abs(e.clientY - ty));
      }
      tx = e.clientX; ty = e.clientY; dernierMouv = now;
      if (!souris) { if (lueur < 0.05) { x = tx; y = ty; } souris = true; }
      /* Sur son passage, la souris laisse pétiller une petite étoile tous les quelques pixels. */
      while (chemin >= PAS_TRACE) { chemin -= PAS_TRACE; semer(tx, ty, 1, 0, 3.5, 7); }
      relancer();
    }, { passive: true });
    window.addEventListener('pointerdown', function (e) {
      if ((e.pointerType && e.pointerType !== 'mouse') || e.button !== 0) { return; }
      semer(e.clientX, e.clientY, 6, 150, 4, 8);
      relancer();
    }, { passive: true });
    window.addEventListener('scroll', relancer, { passive: true });
    root.addEventListener('mouseleave', function () { souris = false; });
    /* Au-dessus d'une iframe (calendrier de réservation), la page ne reçoit plus la souris. */
    document.addEventListener('pointerover', function (e) {
      if (e.target && e.target.tagName === 'IFRAME') { souris = false; }
    }, { passive: true });
    relancer();
  }
  if (document.readyState === 'complete') { demarrer(); } else { window.addEventListener('load', demarrer); }
})();