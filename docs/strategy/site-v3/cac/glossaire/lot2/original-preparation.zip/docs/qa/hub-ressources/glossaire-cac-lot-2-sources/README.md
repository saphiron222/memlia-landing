# Glossaire CAC, lot 2 : risques et seuils

## Résultat et portée

Paquet candidat : `docs/strategy/site-v3/glossaire-cac-lot-2.json`.

Dix entrées, huit sources officielles, 83 unités de preuve, deux articles publiés attestés. Canonical `/glossaire` conservé ; uniquement des ancres, dont `ipe-audit` et `seuil-planification-audit`. Aucun nouveau chemin public, taux universel, score de risque ou opinion produit par un outil. Le lot reste `preview-only` ; `businessReviewer`, `reviewedAt` et les verdicts des unités restent nuls. Revue indépendante attendue sur `t_135675b2`.

Préparation depuis une archive de `origin/main` après fetch, référence `f9b65c7d5a40d6ec6ccf17a3c8dee8f6f93eb73f`. Lecture effectuée : RUNBOOK-QUOTIDIEN §6, SOURCES-DILA, ARCHITECTURE-CAC, `.agents/product-marketing.md`, chaîne resource-pipeline et spécifications resource-metier-evidence / resource-metier-v3. Aucune modification du dépôt de travail principal, commit, push, publication ou construction complète locale. Les sept fichiers globaux comparés à la base sont inchangés (`global-files-check.json`).

## Sources et versions

- NEP 200 : H2A, homologation du 27 novembre 2024, publication au JO du 30 novembre 2024 ; A.821-63, version DILA `LEGIARTI000050697008`, début de validité 1er décembre 2024.
- NEP 315 révisée : H2A, homologation du 13 novembre 2024, publication au JO du 19 novembre 2024 ; A.821-72, version DILA `LEGIARTI000054151014`, début de validité 20 novembre 2024. Le texte prévoit son application aux missions de certification relatives aux exercices ouverts à compter de sa publication au JO. Cette condition est conservée dans les preuves ; ne pas appliquer indifféremment cette version à un exercice plus ancien.
- NEP 320 : H2A, homologation du 28 décembre 2023, publication au JO du 31 décembre 2023 ; A.821-70, version DILA `LEGIARTI000048882384`, début de validité 1er janvier 2024.
- NEP 500 : H2A, homologation du 28 décembre 2023, publication au JO du 31 décembre 2023 ; A.821-74, version DILA `LEGIARTI000048882102`, début de validité 1er janvier 2024.

Les quatre pages H2A ont été réellement ouvertes le 11 octobre 2026, HTTP 200, avec conservation du HTML complet et du texte visible extrait par HTMLParser, sans scripts/styles. Les attestations de version figurent dans les snapshots et `evidence.sources`. `captures.json` décrit ces quatre captures HTTP ; les exports DILA sont décrits dans le paquet.

Les quatre copies DILA ont été exportées par `scripts/export-dila-source.mjs` (voie PR125) depuis le référentiel A4, avec identifiants, textes complets, versions, période et provenance. Collecte originale : `2026-10-05T22:44:11.834561+00:00`, soit le 6 octobre à Paris. `httpStatus` est null : aucune ouverture de Légifrance n’est revendiquée. Une collecte récente du dérivé DINUM ne garantit pas une consolidation récente ni le droit à jour. Les limites A4 et l’absence de comparaison aux pages Légifrance restent applicables.

La fenêtre de fraîcheur de 0 à 7 jours civils Paris inclus est vérifiée au moment de préparation. Pour ces copies DILA, elle se termine le 13 octobre inclus. Une nouvelle préparation/publication après cette fenêtre exige une nouvelle collecte autorisée, sans redater les copies ; le contrôle d’une preuve historique conserve son horodatage d’origine.

## Contenu et rattachement des preuves

Chaque entrée comprend définition, contexte, exemple explicitement fictif, confusion, frontière d’automatisation, termes liés, sources et maillage. Les exemples évitent les montants et pourcentages arbitraires. Le CAC conserve la définition des paramètres, l’évaluation des risques, les diligences, l’appréciation des éléments et les conclusions. Les observations, justifications et décisions saisies ne sont jamais écrasées.

`evidence.units` rattache chaque définition, contexte et confusion à ses sources avec citations exactes de paragraphes et localisation par ligne. Les exemples et frontières Memlia sont des unités distinctes de type `methode-memlia`, sans portée normative propre. `extraits.md` facilite la lecture par terme et source ; les copies complètes restent la référence. Les citations proposées sont des rattachements d’auteur à juger par métier, jamais des PASS sémantiques.

IPE est explicitement une abréviation de pratique, pas une catégorie que les NEP définissent sous cet acronyme. Les exigences concernant les informations produites par l’entité sont rattachées à la NEP 500 §06 ; la pertinence et la fiabilité des informations intégrées aux outils sont rattachées à la NEP 315 §46. Une extraction n’est jamais assimilée à un élément probant suffisant et approprié.

Pour les seuils : la NEP 320 distingue signification et planification ; le second est inférieur au premier. Nature, circonstances et cumul restent appréciés ; la détermination ne devient pas un calcul automatique. Le lot ne prescrit aucun taux ni critère universel. Les paragraphes 06, 07, 09, 14 à 24 utiles sont disponibles dans les preuves.

## Propriétaires et maillage

Les 53 ancres existantes de main ont été examinées : aucune collision avec les dix ancres du lot. Tous les termes liés appartiennent au lot, sans dépendre de la publication d’un autre lot. Les propriétaires existants de C3 sont conservés : aucun nouvel outil signification/planification ni page IPE autonome.

Deux articles EC publiés sur main et effectivement servis en HTTP 200 sont attestés dans `linkChecks`, avec copie HTML contenant le corps d’article et frontmatter `brouillon: false` : vérifier une réponse IA et préparer les données confidentielles. Les libellés n’en font pas des méthodes d’audit ni des preuves CAC.

Les quatre destinations d’articles CAC futurs sont absentes de main et restent dans `deferredLinks`, hors liens publics. Le propriétaire de l’outil C3 signification/planification reste également en table différée : l’intégrateur vérifiera sa livraison effective avant promotion, sans en créer un second. Le statut construit/en revue dans ARCHITECTURE-CAC n’est pas une preuve de publication.

## Compatibilité et intégration

`entries` et `sources` reprennent les interfaces GlossaryEntry et GlossarySource. Seule l’union des dates `GlossaryEntry.sourceCheckedAt` requiert l’ajout explicite de `2026-10-11` à l’intégration groupée. `shape-check.ts` vérifie tous les autres champs contre les interfaces réelles, avec cette seule extension déclarée. Les dates des sources DILA restent `2026-10-06`, sans modification de leur collecte.

Les identifiants de source H2A NEP 200 et DILA A.821-63 sont partagés avec le lot 1. L’intégrateur réutilise ces propriétaires logiques, conserve les captures du lot pour la traçabilité et rattache les revues aux copies réellement examinées ; il ne réécrit pas silencieusement les preuves d’un autre lot.

Ce paquet séparé n’est pas un manifeste global resource-pipeline. La publication groupée conserve la responsabilité de déclarer les nouvelles unités, adapter les planchers et compteurs, injecter la revue indépendante, sceller les surfaces et vérifier la chaîne Ressources, la CI et la production. Aucun PASS de resource-pipeline n’est revendiqué à ce stade.

## Contrôles exécutés

Échec initial du validateur observé avant création du paquet (fichier absent), puis :

- `node docs/qa/hub-ressources/glossaire-cac-lot-2-sources/validate.mjs` : PASS, 10 entrées, 8 sources, 83 unités, 2 liens attestés, 53 ancres examinées. Fraîcheur, intégrité, provenance DILA, citations exactes et localisations contrôlées.
- `node docs/qa/hub-ressources/glossaire-cac-lot-2-sources/mutations.mjs` : 7 mutations refusées (terme manquant, citation inventée, source périmée, lien futur exposé, terme lié absent, empreinte divergente, fausse revue).
- `node --test tests/scripts/dila-source-copy.test.mjs` : 5 tests PASS, sortie conservée dans `tests-dila.log`.
- `tsc --ignoreConfig --noEmit --skipLibCheck --strict --target ES2022 --moduleResolution bundler --module ESNext docs/qa/hub-ressources/glossaire-cac-lot-2-sources/shape-check.ts` : sortie zéro, résultat et commande exacte conservés dans `typecheck-result.json`.
- Comparaison des sept fichiers globaux à la base fraîche : identiques.

Le validateur prouve format, rattachements matériels et preuves d’accès ; la pertinence sémantique des couples affirmation/source relève de la revue métier enfant. L’archive contient les chemins de livraison tels quels et peut être extraite à la racine du dépôt pour refaire les contrôles ciblés.
