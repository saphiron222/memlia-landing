
(function(){
  "use strict";
  var RM = matchMedia('(prefers-reduced-motion:reduce)').matches;
  var $ = function(s){return document.querySelector(s);};
  var $$ = function(s){return Array.prototype.slice.call(document.querySelectorAll(s));};
  var yEl = $('#year'); if(yEl) yEl.textContent = new Date().getFullYear();

  /* ===== MOTEUR ===== */
  // Automatisations : frequence/an (f), minutes manuelles evitees/dossier/passage (m)
  var AUTOS = [
    { key:'pilotage',  nom:'Pilotage',         em:'&#129517;', f:4,  m:6 },
    { key:'cfe',       nom:'CFE',              em:'&#127970;', f:1,  m:4 },
    { key:'tf',        nom:'Taxes Foncières',  em:'&#127968;', f:1,  m:4 },
    { key:'urssaf',    nom:'URSSAF',           em:'&#127974;', f:2,  m:8 },
    { key:'messagerie',nom:'Messagerie',       em:'&#128236;', f:12, m:3 },
    { key:'habilit',   nom:'Habilitations',    em:'&#128272;', f:2,  m:3 },
    { key:'legales',   nom:'Infos Légales',    em:'&#9878;&#65039;', f:1, m:7 },
    { key:'dette',     nom:'Dette Fiscale',    em:'&#128176;', f:4,  m:2 },
    { key:'bodacc',    nom:'BODACC',           em:'&#128220;', f:12, m:1 }
  ];
  var TIERS = [
    { key:'demarrage',  nom:'Démarrage',   prix:600,  min:0,   max:100, range:'0 à 100 dossiers' },
    { key:'croissance', nom:'Croissance',  prix:1200, min:101, max:250, range:'101 à 250 dossiers' },
    { key:'performance',nom:'Performance', prix:1800, min:251, max:500, range:'251 à 500 dossiers' },
    { key:'surmesure',  nom:'Sur-mesure',  prix:null, min:501, max:Infinity, range:'plus de 500 dossiers' }
  ];
  function tierFor(d){
    if(d<=100) return TIERS[0];
    if(d<=250) return TIERS[1];
    if(d<=500) return TIERS[2];
    return TIERS[3];
  }
  function compute(dossiers, taux){
    var heuresAn = 0;
    AUTOS.forEach(function(a){ heuresAn += dossiers * a.f * a.m; });
    heuresAn = heuresAn / 60;
    var valeurBrute = heuresAn * taux;
    var tier = tierFor(dossiers);
    var prix = tier.prix; // null si sur-mesure
    var gainNet = prix==null ? null : (valeurBrute - prix);
    var roi = (prix==null||prix===0) ? null : Math.round(gainNet / prix * 100);
    var jours = (prix==null||valeurBrute<=0) ? null : Math.ceil(prix / valeurBrute * 365);
    return { heuresAn:heuresAn, valeurBrute:valeurBrute, tier:tier, prix:prix, gainNet:gainNet, roi:roi, jours:jours };
  }

  /* ===== FORMATAGE ===== */
  var nf = new Intl.NumberFormat('fr-FR');
  function eur(n){ return nf.format(Math.round(n)) + ' €'; }
  function eurSigned(n){ return (n>=0?'+':'−') + nf.format(Math.abs(Math.round(n))) + ' €'; }
  function hrs(n){ return nf.format(Math.round(n)); }

  /* ===== ELEMENTS ===== */
  var sD = $('#sDossiers'), sT = $('#sTaux');
  var vD = $('#vDossiers'), vT = $('#vTaux');
  var empty = $('#empty'), stack = $('#stack');

  function paintRange(el){
    var min = +el.min, max = +el.max, val = +el.value;
    var pct = (val-min)/(max-min)*100;
    el.style.background = 'linear-gradient(90deg,var(--blue) '+pct+'%,var(--blue-100) '+pct+'%)';
  }

  function renderCalcRows(dossiers){
    var rows = '', total = 0;
    AUTOS.forEach(function(a){
      var h = dossiers * a.f * a.m / 60;
      total += h;
      rows += '<tr><td><span class="em">'+a.em+'</span>'+a.nom+'</td><td class="num">'+a.f+'</td><td class="num">'+a.m+'</td><td class="num">'+nf.format(Math.round(h*10)/10)+'</td></tr>';
    });
    $('#calcRows').innerHTML = rows;
    $('#calcTotal').textContent = nf.format(Math.round(total));
  }

  function update(){
    var dossiers = +sD.value, taux = +sT.value;
    vD.textContent = nf.format(dossiers);
    vT.textContent = taux + ' €/h';
    paintRange(sD); paintRange(sT);

    if(dossiers <= 0){
      empty.style.display = '';
      stack.classList.add('hidden');
      return;
    }
    empty.style.display = 'none';
    stack.classList.remove('hidden');

    var r = compute(dossiers, taux);
    var tier = r.tier;

    // offre
    $('#oNom').textContent = tier.nom;
    $('#oRange').textContent = tier.range;
    $('#oPrix').textContent = r.prix==null ? 'Sur devis' : eur(r.prix);

    // echelle
    $$('#tiers .tier').forEach(function(t){ t.classList.toggle('on', t.dataset.tier===tier.key); });

    // KPIs communs
    $('#kHeures').textContent = hrs(r.heuresAn);
    $('#kValeur').textContent = eur(r.valeurBrute);

    var verdict = $('#verdict'), ctaChoose = $('#ctaChoose');

    if(r.prix==null){
      // SUR-MESURE
      verdict.innerHTML = 'À <b>'+nf.format(dossiers)+' dossiers</b>, votre cabinet relève de l\'offre <b>sur-mesure</b>. Vous économisez déjà <b class="big">'+hrs(r.heuresAn)+' heures</b> par an, soit <b>'+eur(r.valeurBrute)+'</b> de temps valorisé. Parlons de vos conditions.';
      $('#kGain').textContent = eur(r.valeurBrute);
      $('#kGain').previousElementSibling; // noop
      $('#kRoi').textContent = 'Sur devis';
      $('#kJours').textContent = 'n/a';
      ctaChoose.firstChild.textContent = 'Demander un devis ';
      ctaChoose.setAttribute('href', '#');
      ctaChoose.setAttribute('data-cal-namespace','demo30minutes');
      ctaChoose.setAttribute('data-cal-link','outils-ec.fr/demo30minutes');
    } else {
      verdict.innerHTML = 'À <b>'+nf.format(dossiers)+' dossiers</b>, la formule <b>'+tier.nom+'</b> ('+eur(r.prix)+'/an) est rentabilisée en <b class="big">'+r.jours+' jours</b>. Gain net estimé : <b class="big">'+eurSigned(r.gainNet)+'</b> par an.';
      $('#kGain').textContent = eurSigned(r.gainNet);
      $('#kRoi').textContent = nf.format(r.roi) + ' %';
      $('#kJours').textContent = r.jours;
      ctaChoose.firstChild.textContent = 'Choisir ' + tier.nom + ' ';
      ctaChoose.setAttribute('href', '/#formules');
      ctaChoose.removeAttribute('data-cal-namespace');
      ctaChoose.removeAttribute('data-cal-link');
    }

    // detail
    renderCalcRows(dossiers);
    $('#calcMeta').innerHTML = 'Total <b>'+hrs(r.heuresAn)+' h</b> × <b>'+taux+' €/h</b> = <b>'+eur(r.valeurBrute)+'</b> de temps valorisé par an. Prix formule '+tier.nom+(r.prix==null?' : sur devis.':' : <b>'+eur(r.prix)+'</b> HT par an.');
  }

  sD.addEventListener('input', update);
  sT.addEventListener('input', update);
  update();

  /* sur-mesure : ouvre Cal.eu (data-cal gere par embed). repli si absent. */
  $('#surMesure').addEventListener('click', function(){
    if(window.Cal && Cal.ns && Cal.ns.demo30minutes){
      Cal.ns.demo30minutes('modal', { calLink:'outils-ec.fr/demo30minutes' });
    }
  });

  /* nav scroll */
  var nav = $('#nav');
  var onScroll = function(){ nav.classList.toggle('scrolled', window.scrollY > 8); };
  window.addEventListener('scroll', onScroll, {passive:true}); onScroll();

  /* dropdown Outils gratuits : géré en CSS (survol .nav-dd) */

  /* burger */
  var burger = $('#burger'), mob = $('#mobnav');
  burger.addEventListener('click', function(){ mob.classList.toggle('open'); });
  $$('#mobnav a, #mobnav button').forEach(function(a){ a.addEventListener('click', function(){ mob.classList.remove('open'); }); });

  /* cookies */
  var ck = $('#cookies');
  try{ if(!localStorage.getItem('oec_cookies_v1')) ck.removeAttribute('hidden'); }catch(e){ ck.removeAttribute('hidden'); }
  function closeCk(v){ try{ localStorage.setItem('oec_cookies_v1', v); }catch(e){} ck.setAttribute('hidden',''); }
  var a=$('#ck-accept'), r=$('#ck-refuse');
  if(a) a.addEventListener('click', function(){ closeCk('accept'); });
  if(r) r.addEventListener('click', function(){ closeCk('refuse'); });
})();
