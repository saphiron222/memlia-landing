import type { GlossaryEntry, GlossarySource } from '../../../../src/data/glossary';
type CandidateEntry = Omit<GlossaryEntry, 'sourceCheckedAt'> & { sourceCheckedAt: GlossaryEntry['sourceCheckedAt'] | '2026-10-11' };
const data = {
  "entries": [
    {
      "id": "assertions-audit",
      "term": "Assertions",
      "definition": "Les assertions sont les critères dont la réalisation conditionne la régularité, la sincérité et l’image fidèle des comptes. Elles permettent de préciser ce que les travaux d’audit cherchent à vérifier.",
      "context": "La NEP 500, reprise à l’article A.821-74 du Code de commerce, distingue notamment la réalité et la séparation des exercices pour les opérations, l’existence pour les soldes et les assertions relatives à l’annexe. La NEP 315 révisée définit les assertions pertinentes à partir des risques identifiés avant prise en compte des contrôles.",
      "exampleFictitious": "Dans un dossier fictif, une vente enregistrée en décembre mais livrée en janvier conduit l’équipe à examiner la séparation des exercices. Le seul rapprochement du total des ventes ne répond pas à cette question.",
      "commonConfusion": "Une assertion n’est ni une déclaration de la direction ni le nom d’un test. Le contrôle porte sur une ou plusieurs assertions ; son résultat doit être apprécié pour fonder une conclusion.",
      "automationBoundary": "Nous préparons les rapprochements et les renvois selon les assertions retenues par le CAC ; il choisit les travaux et apprécie leurs résultats. Une donnée de période absente suspend la comparaison, sans modifier les commentaires saisis.",
      "relatedTerms": [
        "anomalie-significative",
        "risque-inherent",
        "ipe-audit"
      ],
      "anchor": "assertions-audit",
      "nature": "Réglementaire",
      "internalLinks": [
        {
          "label": "Vérifier une proposition d’IA en comptabilité : une checklist, pas une conclusion d’audit",
          "href": "/blog/verifier-reponse-ia-comptabilite"
        }
      ],
      "owner": "Commissariat aux comptes",
      "author": "Memlia",
      "editorialReviewer": "Équipe éditoriale Memlia",
      "businessReviewer": null,
      "reviewedAt": null,
      "sourceCheckedAt": "2026-10-11",
      "nextReviewAt": "2026-12-13",
      "sourceIds": [
        "h2a-nep-500",
        "dila-a821-74",
        "h2a-nep-315"
      ],
      "motsSources": {
        "h2a-nep-500": "assertions",
        "dila-a821-74": "A.821-74",
        "h2a-nep-315": "assertions pertinentes"
      },
      "routeDecision": "anchor",
      "status": "preview-only"
    },
    {
      "id": "anomalie-significative",
      "term": "Anomalie significative",
      "definition": "Une anomalie significative est une information comptable ou financière inexacte, insuffisante ou omise, en raison d’erreurs ou de fraude, dont l’importance, seule ou cumulée avec d’autres, peut influencer le jugement de l’utilisateur de cette information.",
      "context": "La NEP 200 donne cette définition. La NEP 320 précise que le caractère significatif s’apprécie selon le montant, la nature et les circonstances de l’anomalie ; cette appréciation relève du jugement professionnel du CAC.",
      "exampleFictitious": "Dans un dossier fictif, une information requise manque dans l’annexe. Le CAC examine sa nature et les besoins des utilisateurs, même si aucun montant élevé ne ressort du tableau des écarts.",
      "commonConfusion": "Une anomalie ne devient pas significative uniquement parce qu’un montant dépasse un seuil. Une anomalie de montant inférieur peut être significative par sa nature ou ses circonstances ; plusieurs anomalies peuvent aussi se cumuler.",
      "automationBoundary": "Nous récapitulons les écarts et leurs pièces, sans les qualifier automatiquement de significatifs ni de fraude. Le CAC apprécie montant, nature, cumul et circonstances ; ses qualifications et conclusions restent préservées.",
      "relatedTerms": [
        "seuil-signification-audit",
        "seuil-planification-audit",
        "risque-audit"
      ],
      "anchor": "anomalie-significative",
      "nature": "Réglementaire",
      "internalLinks": [
        {
          "label": "Vérifier une proposition d’IA en comptabilité : une checklist, pas une conclusion d’audit",
          "href": "/blog/verifier-reponse-ia-comptabilite"
        }
      ],
      "owner": "Commissariat aux comptes",
      "author": "Memlia",
      "editorialReviewer": "Équipe éditoriale Memlia",
      "businessReviewer": null,
      "reviewedAt": null,
      "sourceCheckedAt": "2026-10-11",
      "nextReviewAt": "2026-12-13",
      "sourceIds": [
        "h2a-nep-200",
        "h2a-nep-320"
      ],
      "motsSources": {
        "h2a-nep-200": "anomalie significative",
        "h2a-nep-320": "caractère significatif"
      },
      "routeDecision": "anchor",
      "status": "preview-only"
    },
    {
      "id": "risque-audit",
      "term": "Risque d’audit",
      "definition": "Le risque d’audit est le risque que le CAC exprime une opinion différente de celle qu’il aurait émise s’il avait identifié toutes les anomalies significatives dans les comptes. Il comprend le risque d’anomalies significatives et le risque de non-détection de ces anomalies.",
      "context": "La NEP 200, homologuée à l’article A.821-63 du Code de commerce, distingue le risque propre à l’entité du risque de non-détection propre à la mission. Le CAC réduit le risque d’audit à un niveau suffisamment faible pour obtenir l’assurance recherchée, en évaluant les risques et en concevant les procédures adaptées.",
      "exampleFictitious": "Dans une mission fictive, une estimation complexe appelle des travaux spécifiques. Le CAC apprécie les risques et la réponse d’audit ; le tableau qui rassemble les pièces ne calcule pas la sécurité de l’opinion.",
      "commonConfusion": "Le risque d’audit n’est pas seulement le risque de non-détection, ni le risque économique de l’entité. L’absence d’alerte dans un traitement ne démontre pas que le risque d’audit a été réduit au niveau recherché.",
      "automationBoundary": "Nous rassemblons les éléments, paramètres et exceptions dans une proposition distincte ; le CAC évalue les risques et décide de la réponse d’audit. Aucun score automatique ne porte cette appréciation et aucune saisie de risque n’est écrasée.",
      "relatedTerms": [
        "risque-inherent",
        "risque-lie-controle",
        "risque-non-detection"
      ],
      "anchor": "risque-audit",
      "nature": "Réglementaire",
      "internalLinks": [],
      "owner": "Commissariat aux comptes",
      "author": "Memlia",
      "editorialReviewer": "Équipe éditoriale Memlia",
      "businessReviewer": null,
      "reviewedAt": null,
      "sourceCheckedAt": "2026-10-11",
      "nextReviewAt": "2026-12-13",
      "sourceIds": [
        "h2a-nep-200",
        "dila-a821-63"
      ],
      "motsSources": {
        "h2a-nep-200": "risque d’audit",
        "dila-a821-63": "A.821-63"
      },
      "routeDecision": "anchor",
      "status": "preview-only"
    },
    {
      "id": "risque-inherent",
      "term": "Risque inhérent",
      "definition": "Le risque inhérent correspond à la possibilité qu’une anomalie significative se produise dans les comptes sans tenir compte du contrôle interne qui pourrait exister dans l’entité. Il constitue une composante du risque d’anomalies significatives.",
      "context": "La NEP 200 distingue ce risque du risque lié au contrôle. Selon la NEP 315 révisée, le CAC évalue séparément ces deux risques au niveau des assertions ; la complexité, la subjectivité, les changements ou la forte volumétrie peuvent être des facteurs de risque inhérent.",
      "exampleFictitious": "Une entité fictive évalue un actif à partir d’hypothèses incertaines. L’équipe rassemble les hypothèses et leurs versions ; le CAC apprécie le risque inhérent avant de prendre en compte les contrôles de l’entité.",
      "commonConfusion": "Un contrôle interne efficace ne fait pas disparaître le risque inhérent de la définition : celui-ci est apprécié sans tenir compte des contrôles. Complexité et forte volumétrie sont des facteurs à examiner, pas des niveaux de risque attribués automatiquement.",
      "automationBoundary": "Nous préparons l’inventaire des hypothèses, changements et pièces ; le CAC identifie les facteurs pertinents et évalue le risque. Une hypothèse manquante reste signalée, jamais remplacée par une estimation de l’outil.",
      "relatedTerms": [
        "risque-lie-controle",
        "risque-audit",
        "assertions-audit"
      ],
      "anchor": "risque-inherent",
      "nature": "Réglementaire",
      "internalLinks": [],
      "owner": "Commissariat aux comptes",
      "author": "Memlia",
      "editorialReviewer": "Équipe éditoriale Memlia",
      "businessReviewer": null,
      "reviewedAt": null,
      "sourceCheckedAt": "2026-10-11",
      "nextReviewAt": "2026-12-13",
      "sourceIds": [
        "h2a-nep-200",
        "h2a-nep-315"
      ],
      "motsSources": {
        "h2a-nep-200": "risque inhérent",
        "h2a-nep-315": "NEP 315 révisée"
      },
      "routeDecision": "anchor",
      "status": "preview-only"
    },
    {
      "id": "risque-lie-controle",
      "term": "Risque lié au contrôle",
      "definition": "Le risque lié au contrôle est le risque qu’une anomalie significative ne soit ni prévenue ni détectée par le contrôle interne de l’entité, et donc ne soit pas corrigée en temps voulu. Il est distinct du risque inhérent.",
      "context": "La NEP 200 définit ce risque. La NEP 315 révisée distingue l’appréciation de la conception et de la mise en œuvre des contrôles de leurs tests de fonctionnement. Lorsque le CAC ne teste pas l’efficacité du fonctionnement des contrôles, l’évaluation du risque d’anomalies significatives au niveau des assertions correspond à l’évaluation du risque inhérent.",
      "exampleFictitious": "Une procédure fictive prévoit une validation des paiements, mais aucune trace n’est fournie pour la période examinée. Le CAC décide des travaux nécessaires ; la présence de la procédure écrite ne prouve pas son fonctionnement.",
      "commonConfusion": "Décrire un contrôle n’est pas tester son efficacité. Le risque lié au contrôle concerne les contrôles de l’entité, tandis que le risque de non-détection concerne la mission d’audit.",
      "automationBoundary": "Nous préparons l’inventaire des contrôles et rattachons les traces fournies, sans déclarer le contrôle efficace. Le CAC décide s’il s’appuie sur les contrôles et apprécie les tests ; une trace manquante suspend la proposition de rapprochement.",
      "relatedTerms": [
        "controle-interne-audit",
        "risque-inherent",
        "risque-non-detection"
      ],
      "anchor": "risque-lie-controle",
      "nature": "Réglementaire",
      "internalLinks": [],
      "owner": "Commissariat aux comptes",
      "author": "Memlia",
      "editorialReviewer": "Équipe éditoriale Memlia",
      "businessReviewer": null,
      "reviewedAt": null,
      "sourceCheckedAt": "2026-10-11",
      "nextReviewAt": "2026-12-13",
      "sourceIds": [
        "h2a-nep-200",
        "h2a-nep-315"
      ],
      "motsSources": {
        "h2a-nep-200": "risque lié au contrôle",
        "h2a-nep-315": "NEP 315 révisée"
      },
      "routeDecision": "anchor",
      "status": "preview-only"
    },
    {
      "id": "risque-non-detection",
      "term": "Risque de non-détection",
      "definition": "Le risque de non-détection est le risque que le CAC ne parvienne pas à détecter une anomalie significative. Propre à la mission d’audit, il constitue l’une des composantes du risque d’audit.",
      "context": "La NEP 200 distingue ce risque du risque d’anomalies significatives propre à l’entité. Plus le CAC évalue ce dernier à un niveau élevé, plus il met en œuvre de procédures d’audit complémentaires afin de réduire le risque de non-détection.",
      "exampleFictitious": "Dans un dossier fictif, une analyse ne couvre qu’une partie des écritures reçues. L’équipe présente cette limite au CAC, qui apprécie la nécessité de travaux complémentaires avant de conclure.",
      "commonConfusion": "Le risque de non-détection ne désigne pas une faiblesse du contrôle interne de l’entité. Examiner davantage de données par un outil ne suffit pas, à lui seul, à démontrer l’obtention de l’assurance recherchée.",
      "automationBoundary": "Nous présentons la population reçue, celle traitée et les exclusions ; le CAC décide des procédures et apprécie les éléments collectés. L’outil ne chiffre pas le risque résiduel et ne transforme pas une population incomplète en conclusion.",
      "relatedTerms": [
        "risque-audit",
        "risque-lie-controle",
        "ipe-audit"
      ],
      "anchor": "risque-non-detection",
      "nature": "Réglementaire",
      "internalLinks": [
        {
          "label": "Vérifier une proposition d’IA en comptabilité : une checklist, pas une conclusion d’audit",
          "href": "/blog/verifier-reponse-ia-comptabilite"
        }
      ],
      "owner": "Commissariat aux comptes",
      "author": "Memlia",
      "editorialReviewer": "Équipe éditoriale Memlia",
      "businessReviewer": null,
      "reviewedAt": null,
      "sourceCheckedAt": "2026-10-11",
      "nextReviewAt": "2026-12-13",
      "sourceIds": [
        "h2a-nep-200"
      ],
      "motsSources": {
        "h2a-nep-200": "risque de non-détection"
      },
      "routeDecision": "anchor",
      "status": "preview-only"
    },
    {
      "id": "seuil-signification-audit",
      "term": "Seuil de signification",
      "definition": "Le seuil de signification est le montant au-delà duquel les décisions économiques ou le jugement fondé sur les comptes sont susceptibles d’être influencés. Il aide à apprécier le caractère significatif des anomalies selon leur montant.",
      "context": "La NEP 320, reprise à l’article A.821-70 du Code de commerce, confie au CAC le choix des critères et des modalités de calcul. Il détermine un seuil pour les comptes pris dans leur ensemble et apprécie si des seuils inférieurs sont nécessaires pour certains flux, soldes ou informations ; la nature et les circonstances des anomalies restent à examiner.",
      "exampleFictitious": "Dans un dossier fictif, le CAC retient un critère adapté à l’entité et consigne sa justification. Un fait nouveau modifie les données disponibles : il reconsidère le seuil et documente sa décision.",
      "commonConfusion": "Le seuil de signification n’est ni un taux universel ni une autorisation d’ignorer les anomalies de montant inférieur. Il se distingue du seuil de planification, qui est inférieur et sert à définir la nature et l’étendue des travaux.",
      "automationBoundary": "Nous exécutons le calcul avec les paramètres choisis et validés par le CAC, et présentons les versions séparément de ses justifications. Un paramètre absent suspend le calcul ; le CAC conserve le choix du critère, des montants et de leurs modifications.",
      "relatedTerms": [
        "seuil-planification-audit",
        "anomalie-significative",
        "risque-audit"
      ],
      "anchor": "seuil-signification-audit",
      "nature": "Réglementaire",
      "internalLinks": [],
      "owner": "Commissariat aux comptes",
      "author": "Memlia",
      "editorialReviewer": "Équipe éditoriale Memlia",
      "businessReviewer": null,
      "reviewedAt": null,
      "sourceCheckedAt": "2026-10-11",
      "nextReviewAt": "2026-12-13",
      "sourceIds": [
        "h2a-nep-320",
        "dila-a821-70"
      ],
      "motsSources": {
        "h2a-nep-320": "seuil de signification",
        "dila-a821-70": "A.821-70"
      },
      "routeDecision": "anchor",
      "status": "preview-only"
    },
    {
      "id": "seuil-planification-audit",
      "term": "Seuil de planification",
      "definition": "Le seuil de planification est un montant inférieur au seuil de signification, utilisé par le CAC pour définir la nature et l’étendue de ses travaux. Il vise à réduire à un niveau acceptable le risque que les anomalies relevées non corrigées et les anomalies non détectées excèdent ensemble le seuil de signification.",
      "context": "La NEP 320, reprise à l’article A.821-70 du Code de commerce, précise que sa détermination ne relève pas du seul calcul arithmétique : le CAC exerce son jugement professionnel à partir de sa connaissance de l’entité et du risque d’anomalies, notamment au vu des audits précédents. Les seuils retenus et les critères de détermination figurent au dossier.",
      "exampleFictitious": "Dans une mission fictive, le CAC retient un seuil de planification inférieur au seuil de signification et explique son choix dans le dossier. Le tableau conserve cette justification, sans proposer un pourcentage par défaut.",
      "commonConfusion": "Le seuil de planification n’est pas le seuil de signification ni un simple pourcentage obligatoire. Il ne rend pas automatiquement sans importance les anomalies situées en dessous de son montant.",
      "automationBoundary": "Nous préparons le calcul et la comparaison des montants avec les paramètres validés ; une incohérence entre les seuils arrête la proposition. Le CAC fixe et justifie les montants, décide des travaux et garde ses saisies ; aucun taux n’est recommandé par l’outil.",
      "relatedTerms": [
        "seuil-signification-audit",
        "anomalie-significative",
        "risque-non-detection"
      ],
      "anchor": "seuil-planification-audit",
      "nature": "Réglementaire",
      "internalLinks": [],
      "owner": "Commissariat aux comptes",
      "author": "Memlia",
      "editorialReviewer": "Équipe éditoriale Memlia",
      "businessReviewer": null,
      "reviewedAt": null,
      "sourceCheckedAt": "2026-10-11",
      "nextReviewAt": "2026-12-13",
      "sourceIds": [
        "h2a-nep-320",
        "dila-a821-70"
      ],
      "motsSources": {
        "h2a-nep-320": "seuil de planification",
        "dila-a821-70": "A.821-70"
      },
      "routeDecision": "anchor",
      "status": "preview-only"
    },
    {
      "id": "controle-interne-audit",
      "term": "Contrôle interne",
      "definition": "Le contrôle interne est l’ensemble des moyens, comportements, procédures et actions conçus, mis en œuvre et suivis par l’entité, adaptés à ses caractéristiques. Il vise notamment la conformité aux lois et règlements, l’application des orientations de la direction, le bon fonctionnement des processus et la fiabilité des informations financières.",
      "context": "La NEP 315 révisée, reprise à l’article A.821-72 du Code de commerce, distingue cinq composantes : environnement de contrôle, processus d’évaluation des risques, pilotage, système d’information et communication, activités de contrôle. Pour l’audit, la prise de connaissance et l’appréciation de ces composantes portent sur les éléments relatifs à la préparation des comptes.",
      "exampleFictitious": "Dans une entité fictive, la séparation des rôles et la validation des achats sont décrites dans une procédure. Le CAC examine leur conception et leur mise en œuvre ; un inventaire de procédures ne suffit pas à en démontrer l’efficacité.",
      "commonConfusion": "Le contrôle interne ne se réduit ni à une checklist ni à un logiciel. L’appréciation de la conception et de la mise en œuvre d’un contrôle se distingue des tests de l’efficacité de son fonctionnement.",
      "automationBoundary": "Nous préparons les descriptions, renvois et traces dans une zone de proposition ; le CAC apprécie les composantes et les contrôles, puis décide de ses travaux. Les observations saisies restent intactes ; un renvoi absent est signalé, jamais reconstitué sans pièce.",
      "relatedTerms": [
        "risque-lie-controle",
        "ipe-audit",
        "assertions-audit"
      ],
      "anchor": "controle-interne-audit",
      "nature": "Réglementaire",
      "internalLinks": [],
      "owner": "Commissariat aux comptes",
      "author": "Memlia",
      "editorialReviewer": "Équipe éditoriale Memlia",
      "businessReviewer": null,
      "reviewedAt": null,
      "sourceCheckedAt": "2026-10-11",
      "nextReviewAt": "2026-12-13",
      "sourceIds": [
        "h2a-nep-315",
        "dila-a821-72"
      ],
      "motsSources": {
        "h2a-nep-315": "contrôle interne",
        "dila-a821-72": "A.821-72"
      },
      "routeDecision": "anchor",
      "status": "preview-only"
    },
    {
      "id": "ipe-audit",
      "term": "Informations produites par l’entité (IPE)",
      "definition": "Les informations produites par l’entité, souvent appelées IPE en pratique d’audit, sont les informations internes que le CAC utilise pour mettre en œuvre ses procédures : états, extractions ou tableaux préparés par l’entité. Leur origine interne ne suffit pas à établir leur fiabilité.",
      "context": "La NEP 500, reprise à l’article A.821-74 du Code de commerce, demande au CAC qui utilise des informations produites par l’entité de collecter des éléments concernant leur exactitude et leur exhaustivité. La NEP 315 révisée précise aussi l’appréciation de la pertinence et de la fiabilité des informations intégrées dans les outils automatisés.",
      "exampleFictitious": "Une extraction fictive des créances exclut les comptes soldés et porte sur une mauvaise période. L’équipe conserve les filtres, rapproche les données reçues et signale la limite au CAC ; le fichier n’est pas réputé complet parce qu’il a été exporté.",
      "commonConfusion": "Une IPE n’est pas automatiquement un élément probant suffisant et approprié. Un état exporté par le système de l’entité ou un total rapproché ne dispense pas d’examiner l’exactitude, l’exhaustivité et la pertinence des informations utilisées.",
      "automationBoundary": "Nous préparons une fiche d’extraction avec source, période, filtres, population reçue et écarts ; une origine ou un filtre inconnu suspend le traitement. Le CAC choisit les contrôles et apprécie le caractère probant ; les limites et commentaires saisis ne sont jamais écrasés.",
      "relatedTerms": [
        "assertions-audit",
        "controle-interne-audit",
        "risque-non-detection"
      ],
      "anchor": "ipe-audit",
      "nature": "Professionnelle",
      "internalLinks": [
        {
          "label": "Préparer les données avant une transmission à l’IA en cabinet comptable",
          "href": "/blog/ia-comptabilite-confidentialite-donnees"
        }
      ],
      "owner": "Commissariat aux comptes",
      "author": "Memlia",
      "editorialReviewer": "Équipe éditoriale Memlia",
      "businessReviewer": null,
      "reviewedAt": null,
      "sourceCheckedAt": "2026-10-11",
      "nextReviewAt": "2026-12-13",
      "sourceIds": [
        "h2a-nep-500",
        "dila-a821-74",
        "h2a-nep-315"
      ],
      "motsSources": {
        "h2a-nep-500": "informations produites par l’entité",
        "dila-a821-74": "A.821-74",
        "h2a-nep-315": "pertinence et de la fiabilité"
      },
      "routeDecision": "anchor",
      "status": "preview-only"
    }
  ],
  "sources": {
    "h2a-nep-315": {
      "id": "h2a-nep-315",
      "publisher": "H2A",
      "title": "NEP 315 - Prise de connaissance de l’entité et de son environnement, identification et évaluation du risque d’anomalies significatives dans les comptes",
      "url": "https://h2a-france.org/normes/connaissance-de-lentite-et-de-son-environnement-et-evaluation-du-risque-danomalies-significatives-dans-les-comptes/",
      "checkedAt": "2026-10-11"
    },
    "h2a-nep-320": {
      "id": "h2a-nep-320",
      "publisher": "H2A",
      "title": "NEP 320 - Application de la notion de caractère significatif lors de la planification et de la réalisation d’un audit",
      "url": "https://h2a-france.org/normes/application-de-la-notion-de-caractere-significatif-lors-de-la-planification-et-de-la-realisation-dun-audit/",
      "checkedAt": "2026-10-11"
    },
    "h2a-nep-500": {
      "id": "h2a-nep-500",
      "publisher": "H2A",
      "title": "NEP 500 - Caractère probant des éléments collectés",
      "url": "https://h2a-france.org/normes/caractere-probant-des-elements-collectes/",
      "checkedAt": "2026-10-11"
    },
    "h2a-nep-200": {
      "id": "h2a-nep-200",
      "publisher": "H2A",
      "title": "NEP 200 - Principes applicables à l’audit des comptes mis en œuvre dans le cadre de la certification des comptes",
      "url": "https://h2a-france.org/normes/audit-des-comptes-mis-en-oeuvre-dans-le-cadre-de-la-certification-des-comptes/",
      "checkedAt": "2026-10-11"
    },
    "dila-a821-63": {
      "id": "dila-a821-63",
      "publisher": "Légifrance — DILA/DINUM",
      "title": "Code de commerce, A.821-63",
      "url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000050697008",
      "checkedAt": "2026-10-06"
    },
    "dila-a821-70": {
      "id": "dila-a821-70",
      "publisher": "Légifrance — DILA/DINUM",
      "title": "Code de commerce, A.821-70",
      "url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048882384",
      "checkedAt": "2026-10-06"
    },
    "dila-a821-72": {
      "id": "dila-a821-72",
      "publisher": "Légifrance — DILA/DINUM",
      "title": "Code de commerce, A.821-72",
      "url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054151014",
      "checkedAt": "2026-10-06"
    },
    "dila-a821-74": {
      "id": "dila-a821-74",
      "publisher": "Légifrance — DILA/DINUM",
      "title": "Code de commerce, A.821-74",
      "url": "https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048882102",
      "checkedAt": "2026-10-06"
    }
  }
} as const;
const entries: CandidateEntry[] = data.entries.map(e => ({ ...e, relatedTerms: [...e.relatedTerms], internalLinks: [...e.internalLinks], sourceIds: [...e.sourceIds] }));
const sources: Record<string, GlossarySource> = data.sources;
void entries; void sources;
