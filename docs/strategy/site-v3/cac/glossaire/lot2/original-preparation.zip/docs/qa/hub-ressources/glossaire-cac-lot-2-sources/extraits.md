# Extraits exacts : risques et seuils
Les textes ci-dessous sont copiés mot pour mot des snapshots ; ils ne constituent pas une revue métier. Les numéros de paragraphe et lignes sont conservés.

## Assertions (`assertions-audit`)

### h2a-nep-500
https://h2a-france.org/normes/caractere-probant-des-elements-collectes/

h2a-nep-500:paragraphe-03:ligne-67

03. Assertions : critères dont la réalisation conditionne la régularité, la sincérité et l’image fidèle des comptes.
Caractère probant

h2a-nep-500:paragraphe-05:ligne-70

05. Ces éléments apportent au commissaire aux comptes des éléments de preuves ou des présomptions quant au respect d’une ou plusieurs assertions. Ces éléments doivent être suffisants et appropriés pour lui permettre de fonder son opinion sur les comptes.

h2a-nep-500:paragraphe-09:ligne-82

09. Les éléments collectés apportent au commissaire aux comptes des éléments de preuves ou des présomptions quant au respect d’une ou plusieurs des assertions suivantes :
Assertions concernant les flux d’opérations et les événements survenus au cours de la période :
– réalité : les opérations et les événements qui ont été enregistrés se sont produits et se rapportent à l’entité ;
– exhaustivité : toutes les opérations et tous les événements qui auraient dû être enregistrés sont enregistrés ;
– mesure : les montants et autres données relatives aux opérations et événements ont été correctement enregistrés ;
– séparation des exercices : les opérations et les événements ont été enregistrés dans la bonne période ;
– classification : les opérations et les événements ont été enregistrés dans les comptes adéquats.
Les assertions concernant les soldes des comptes en fin de période :
– existence : les actifs et les passifs existent ;
– droits et obligations : l’entité détient et contrôle les droits sur les actifs, et les dettes correspondent aux obligations de l’entité ;
– exhaustivité : tous les actifs et les passifs qui auraient dû être enregistrés l’ont bien été ;
– évaluation et imputation : les actifs et les passifs sont inscrits dans les comptes pour des montants appropriés et tous les ajustements résultant de leur évaluation ou imputation sont correctement enregistrés.
Les assertions concernant la présentation des comptes et les informations fournies dans l’annexe :
– réalité et droits et obligations : les événements, les transactions et les autres éléments fournis se sont produits et se rapportent à l’entité ;
– exhaustivité : toutes les informations relatives à l’annexe des comptes requises par le référentiel comptable ont été fournies ;
– présentation et intelligibilité : l’information financière est présentée et décrite de manière appropriée, et les informations données dans l’annexe des comptes sont clairement présentées ;
– mesure et évaluation : les informations financières et les autres informations sont données fidèlement et pour les bons montants.
Techniques de contrôle

### dila-a821-74
https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048882102

dila-a821-74:paragraphe-3:ligne-7

3. Assertions : critères dont la réalisation conditionne la régularité, la sincérité et l'image fidèle des comptes.
Caractère probant

dila-a821-74:paragraphe-5:ligne-10

5. Ces éléments apportent au commissaire aux comptes des éléments de preuves ou des présomptions quant au respect d'une ou plusieurs assertions. Ces éléments doivent être suffisants et appropriés pour lui permettre de fonder son opinion sur les comptes.

dila-a821-74:paragraphe-9:ligne-22

9. Les éléments collectés apportent au commissaire aux comptes des éléments de preuves ou des présomptions quant au respect d'une ou plusieurs des assertions suivantes :
Assertions concernant les flux d'opérations et les événements survenus au cours de la période :
- réalité : les opérations et les événements qui ont été enregistrés se sont produits et se rapportent à l'entité ;
- exhaustivité : toutes les opérations et tous les événements qui auraient dû être enregistrés sont enregistrés ;
- mesure : les montants et autres données relatives aux opérations et événements ont été correctement enregistrés ;
- séparation des exercices : les opérations et les événements ont été enregistrés dans la bonne période ;
- classification : les opérations et les événements ont été enregistrés dans les comptes adéquats.
Les assertions concernant les soldes des comptes en fin de période :
- existence : les actifs et les passifs existent ;
- droits et obligations : l'entité détient et contrôle les droits sur les actifs, et les dettes correspondent aux obligations de l'entité ;- exhaustivité : tous les actifs et les passifs qui auraient dû être enregistrés l'ont bien été ;
- évaluation et imputation : les actifs et les passifs sont inscrits dans les comptes pour des montants appropriés et tous les ajustements résultant de leur évaluation ou imputation sont correctement enregistrés.
Les assertions concernant la présentation des comptes et les informations fournies dans l'annexe :
- réalité et droits et obligations : les événements, les transactions et les autres éléments fournis se sont produits et se rapportent à l'entité ;
- exhaustivité : toutes les informations relatives à l'annexe des comptes requises par le référentiel comptable ont été fournies ;
- présentation et intelligibilité : l'information financière est présentée et décrite de manière appropriée, et les informations données dans l'annexe des comptes sont clairement présentées ;
- mesure et évaluation : les informations financières et les autres informations sont données fidèlement et pour les bons montants.
Techniques de contrôle

### h2a-nep-315
https://h2a-france.org/normes/connaissance-de-lentite-et-de-son-environnement-et-evaluation-du-risque-danomalies-significatives-dans-les-comptes/

h2a-nep-315:paragraphe-06:ligne-87

06. Assertions pertinentes : assertions portant sur une catégorie d’opérations, un solde de compte ou une information fournie dans l’annexe au niveau desquelles un risque d’anomalies significatives est identifié par le commissaire aux comptes, avant prise en compte des contrôles y afférents, c’est-à-dire en considérant le seul risque inhérent.

h2a-nep-315:paragraphe-17:ligne-104

17. Procédures d’audit : ensemble des travaux réalisés au cours de l’audit afin de collecter les éléments suffisants et appropriés permettant d’aboutir à des conclusions à partir desquelles le commissaire aux comptes fonde son opinion.

## Anomalie significative (`anomalie-significative`)

### h2a-nep-200
https://h2a-france.org/normes/audit-des-comptes-mis-en-oeuvre-dans-le-cadre-de-la-certification-des-comptes/

h2a-nep-200:paragraphe-04:ligne-70

04. Anomalie significative : information comptable ou financière inexacte, insuffisante ou omise, en raison d’erreurs ou de fraude, d’une importance telle que, seule ou cumulée avec d’autres, elle peut influencer le jugement de l’utilisateur d’une information comptable ou financière.
Respect des textes et esprit critique

### h2a-nep-320
https://h2a-france.org/normes/application-de-la-notion-de-caractere-significatif-lors-de-la-planification-et-de-la-realisation-dun-audit/

h2a-nep-320:paragraphe-04:ligne-68

04. Anomalie significative : information comptable ou financière inexacte, insuffisante ou omise, en raison d’erreurs ou de fraude d’une importance telle que, seule ou cumulée avec d’autres, elle peut influencer le jugement de l’utilisateur d’une information financière ou comptable.

h2a-nep-320:paragraphe-09:ligne-74

09. Le commissaire aux comptes met en œuvre la notion de caractère significatif dans le contexte de l’audit des comptes en considérant non seulement le montant des anomalies mais aussi leur nature. Il prend également en compte les circonstances particulières de leur survenance : en effet, les circonstances entourant certaines anomalies peuvent amener le commissaire aux comptes à les juger significatives quand bien même leur montant ne le serait pas.

h2a-nep-320:paragraphe-10:ligne-75

10. La détermination du caractère significatif des anomalies relève du jugement professionnel du commissaire aux comptes et est influencée par sa perception des besoins d’informations financières des utilisateurs des comptes.

## Risque d’audit (`risque-audit`)

### h2a-nep-200
https://h2a-france.org/normes/audit-des-comptes-mis-en-oeuvre-dans-le-cadre-de-la-certification-des-comptes/

h2a-nep-200:paragraphe-10:ligne-82

10. Le risque que le commissaire aux comptes exprime une opinion différente de celle qu’il aurait émise s’il avait identifié toutes les anomalies significatives dans les comptes est appelé « risque d’audit ».
Le risque d’audit comprend deux composantes : le risque d’anomalies significatives dans les comptes et le risque de non-détection de ces anomalies par le commissaire aux comptes.

h2a-nep-200:paragraphe-11:ligne-84

11. Le risque d’anomalies significatives dans les comptes est propre à l’entité ; il existe indépendamment de l’audit des comptes. Il se subdivise en risque inhérent et risque lié au contrôle.
Le risque inhérent correspond à la possibilité que, sans tenir compte du contrôle interne qui pourrait exister dans l’entité, une anomalie significative se produise dans les comptes.
Le risque lié au contrôle correspond au risque qu’une anomalie significative ne soit ni prévenue ni détectée par le contrôle interne de l’entité et donc non corrigée en temps voulu.

h2a-nep-200:paragraphe-12:ligne-87

12. Le risque de non-détection est propre à la mission d’audit : il correspond au risque que le commissaire aux comptes ne parvienne pas à détecter une anomalie significative.

h2a-nep-200:paragraphe-13:ligne-88

13. Le commissaire aux comptes réduit le risque d’audit à un niveau suffisamment faible pour obtenir l’assurance recherchée nécessaire à la certification des comptes.
A cette fin, il évalue le risque d’anomalies significatives et conçoit les procédures d’audit à mettre en œuvre en réponse à cette évaluation, conformément aux principes définis dans les normes d’exercice professionnel.
Plus le commissaire aux comptes évalue le risque d’anomalies significatives à un niveau élevé, plus il met en œuvre de procédures d’audit complémentaires afin de réduire le risque de non-détection.

### dila-a821-63
https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000050697008

dila-a821-63:paragraphe-10:ligne-22

10. Le risque que le commissaire aux comptes exprime une opinion différente de celle qu'il aurait émise s'il avait identifié toutes les anomalies significatives dans les comptes est appelé “ risque d'audit ”.
Le risque d'audit comprend deux composantes : le risque d'anomalies significatives dans les comptes et le risque de non-détection de ces anomalies par le commissaire aux comptes.

dila-a821-63:paragraphe-11:ligne-24

11. Le risque d'anomalies significatives dans les comptes est propre à l'entité ; il existe indépendamment de l'audit des comptes. Il se subdivise en risque inhérent et risque lié au contrôle.
Le risque inhérent correspond à la possibilité que, sans tenir compte du contrôle interne qui pourrait exister dans l'entité, une anomalie significative se produise dans les comptes.
Le risque lié au contrôle correspond au risque qu'une anomalie significative ne soit ni prévenue ni détectée par le contrôle interne de l'entité et donc non corrigée en temps voulu.

dila-a821-63:paragraphe-12:ligne-27

12. Le risque de non-détection est propre à la mission d'audit : il correspond au risque que le commissaire aux comptes ne parvienne pas à détecter une anomalie significative.

dila-a821-63:paragraphe-13:ligne-28

13. Le commissaire aux comptes réduit le risque d'audit à un niveau suffisamment faible pour obtenir l'assurance recherchée nécessaire à la certification des comptes.
A cette fin, il évalue le risque d'anomalies significatives et conçoit les procédures d'audit à mettre en œuvre en réponse à cette évaluation, conformément aux principes définis dans les normes d'exercice professionnel.
Plus le commissaire aux comptes évalue le risque d'anomalies significatives à un niveau élevé, plus il met en œuvre de procédures d'audit complémentaires afin de réduire le risque de non-détection.

## Risque inhérent (`risque-inherent`)

### h2a-nep-200
https://h2a-france.org/normes/audit-des-comptes-mis-en-oeuvre-dans-le-cadre-de-la-certification-des-comptes/

h2a-nep-200:paragraphe-11:ligne-84

11. Le risque d’anomalies significatives dans les comptes est propre à l’entité ; il existe indépendamment de l’audit des comptes. Il se subdivise en risque inhérent et risque lié au contrôle.
Le risque inhérent correspond à la possibilité que, sans tenir compte du contrôle interne qui pourrait exister dans l’entité, une anomalie significative se produise dans les comptes.
Le risque lié au contrôle correspond au risque qu’une anomalie significative ne soit ni prévenue ni détectée par le contrôle interne de l’entité et donc non corrigée en temps voulu.

### h2a-nep-315
https://h2a-france.org/normes/connaissance-de-lentite-et-de-son-environnement-et-evaluation-du-risque-danomalies-significatives-dans-les-comptes/

h2a-nep-315:paragraphe-02:ligne-66

02. Le risque d’anomalies significatives dans les comptes est propre à l’entité et se subdivise en risque inhérent et risque lié au contrôle. Il existe indépendamment de l’audit des comptes.
L’environnement dans lequel évolue l’entité ou encore le processus mis en oeuvre par la direction pour préparer l’information requise par le référentiel comptable applicable peuvent constituer des facteurs de risque inhérent. Ainsi, parmi les facteurs de risque inhérent figurent :
• la complexité induite par la nature de l’information requise par le référentiel comptable applicable ;
les choix de la direction qui peuvent :
• comporter de la subjectivité et de l’incertitude, en particulier du fait des limites inhérentes aux connaissances et aux informations disponibles;
• nécessiter de porter un jugement, en particulier lorsque les éléments concernés par ces choix sont complexes ;
• présenter des indices de biais qui peuvent constituer des facteurs de risques de fraudes ;
• les changements propres à l’entité liés par exemple à une réorganisation, une croissance externe, des changements au sein du personnel ou dans l’environnement informatique ou des changements propres à son environnement, liés par exemple à la conjoncture économique, à une nouvelle réglementation comptable, financière ou environnementale ;
• les caractéristiques du système d’information ;
• le volume élevé de transactions traitées dans le système d’information communément appelé forte volumétrie.
Sur la base des facteurs de risque inhérent identifiés, le commissaire aux comptes évalue la nature et l’ampleur du risque inhérent attaché au risque d’anomalies significatives au niveau des assertions et adapte en conséquence sa démarche d’audit.
Le contrôle interne conçu, mis en oeuvre et suivi par l’entité influe, dans toutes ses composantes, sur le risque lié au contrôle, lequel correspond au risque qu’une anomalie significative ne soit ni prévenue, ni détectée par le contrôle interne de l’entité et donc non corrigée en temps voulu.
Si le commissaire aux comptes prévoit de tester l’efficacité des contrôles, il évalue le risque lié au contrôle. Lorsqu’il ne prévoit pas de s’appuyer sur les contrôles, l’évaluation du risque d’anomalies significatives au niveau des assertions correspond à l’évaluation du risque inhérent.
L’identification et l’évaluation du risque d’anomalies significatives par le commissaire aux comptes résulte d’un processus itératif et dynamique qui se poursuit tout au long de l’audit en fonction des éléments collectés au cours de la mission.

h2a-nep-315:paragraphe-39:ligne-206

39. Pour évaluer le risque d’anomalies significatives au niveau des assertions, le commissaire aux comptes évalue séparément le risque inhérent et le risque lié au contrôle.
Evaluation du risque inhérent

h2a-nep-315:paragraphe-40:ligne-208

40. Le commissaire aux comptes évalue le risque inhérent en déterminant la probabilité et l’ampleur des anomalies. Pour ce faire, il tient compte de la façon et de la mesure dans laquelle :
• les facteurs de risque inhérent ont une incidence sur la possibilité que les assertions pertinentes comportent des anomalies ;
• le risque d’anomalies significatives au niveau des comptes pris dans leur ensemble a une incidence sur l’évaluation du risque inhérent.
Le commissaire aux comptes détermine s’il existe :
• un risque inhérent élevé qui nécessite une démarche d’audit particulière. Un tel risque peut être lié, par exemple, à des opérations non courantes en raison de leur importance et de leur nature ou à des éléments sujets à interprétation, tels que les estimations comptables ;
• un risque d’anomalies significatives au niveau des assertions pour lequel les procédures de substance ne lui permettront pas, à elles-seules, de collecter les éléments suffisants et appropriés. Il peut en être ainsi lorsque le processus de traitement des opérations est fortement automatisé, avec peu ou pas d’intervention manuelle, et que le volume de transactions traité dans le système d’information est élevé.
Evaluation du risque lié au contrôle

## Risque lié au contrôle (`risque-lie-controle`)

### h2a-nep-200
https://h2a-france.org/normes/audit-des-comptes-mis-en-oeuvre-dans-le-cadre-de-la-certification-des-comptes/

h2a-nep-200:paragraphe-11:ligne-84

11. Le risque d’anomalies significatives dans les comptes est propre à l’entité ; il existe indépendamment de l’audit des comptes. Il se subdivise en risque inhérent et risque lié au contrôle.
Le risque inhérent correspond à la possibilité que, sans tenir compte du contrôle interne qui pourrait exister dans l’entité, une anomalie significative se produise dans les comptes.
Le risque lié au contrôle correspond au risque qu’une anomalie significative ne soit ni prévenue ni détectée par le contrôle interne de l’entité et donc non corrigée en temps voulu.

h2a-nep-200:paragraphe-12:ligne-87

12. Le risque de non-détection est propre à la mission d’audit : il correspond au risque que le commissaire aux comptes ne parvienne pas à détecter une anomalie significative.

### h2a-nep-315
https://h2a-france.org/normes/connaissance-de-lentite-et-de-son-environnement-et-evaluation-du-risque-danomalies-significatives-dans-les-comptes/

h2a-nep-315:paragraphe-34:ligne-190

34. Pour chaque contrôle identifié et pour les contrôles généraux informatiques permettant de répondre aux risques liés à l’environnement informatique, le commissaire aux comptes :
• apprécie si la conception du contrôle est efficace pour répondre au risque d’anomalies significatives au niveau des assertions ou pour permettre le fonctionnement d’autres contrôles ;
• détermine si le contrôle a été mis en oeuvre en réalisant des procédures complémentaires à ses demandes d’information auprès du personnel de l’entité et, à l’issue de ces procédures, confirme ou infirme son intention de s’appuyer sur le contrôle.
Faiblesses du contrôle interne de l’entité

h2a-nep-315:paragraphe-41:ligne-215

41. L’appréciation par le commissaire aux comptes des composantes du contrôle interne, notamment des activités de contrôle, lui permet de disposer d’une analyse préliminaire de la conception et de la mise en oeuvre du contrôle interne de l’entité.
Si, en fonction de cette appréciation et à l’issue des travaux mis en oeuvre conformément au paragraphe 33, le commissaire aux comptes prévoit de s’appuyer sur les contrôles pertinents pour sa mission et/ou les procédures de substance, à elles seules, ne permettent pas de collecter les éléments suffisants et appropriés pour répondre au risque d’anomalies significatives au niveau des assertions, il évalue le risque lié au contrôle.
Si, à l’issue de cette évaluation, il estime pouvoir s’appuyer effectivement sur ces contrôles, il teste l’efficacité de leur fonctionnement dans le cadre de sa réponse à l’évaluation du risque d’anomalies significatives au niveau des assertions, conformément aux principes définis dans la norme d’exercice professionnel « Procédures d’audit mises en oeuvre par le commissaire aux comptes à l’issue de sa prise de connaissance de l’entité et de son environnement et de son évaluation du risque d’anomalies significatives dans les comptes ».
Lorsqu’il ne teste pas l’efficacité du fonctionnement des contrôles, l’évaluation du risque d’anomalies significatives au niveau des assertions correspond à l’évaluation du risque inhérent.
Evaluation du caractère suffisant et approprié des éléments collectés

## Risque de non-détection (`risque-non-detection`)

### h2a-nep-200
https://h2a-france.org/normes/audit-des-comptes-mis-en-oeuvre-dans-le-cadre-de-la-certification-des-comptes/

h2a-nep-200:paragraphe-08:ligne-78

08. La formulation, par le commissaire aux comptes, de son opinion sur les comptes nécessite qu’il obtienne l’assurance que les comptes, pris dans leur ensemble, ne comportent pas d’anomalies significatives.
Cette assurance élevée, mais non absolue du fait des limites de l’audit est qualifiée, par convention, d’« assurance raisonnable ».

h2a-nep-200:paragraphe-10:ligne-82

10. Le risque que le commissaire aux comptes exprime une opinion différente de celle qu’il aurait émise s’il avait identifié toutes les anomalies significatives dans les comptes est appelé « risque d’audit ».
Le risque d’audit comprend deux composantes : le risque d’anomalies significatives dans les comptes et le risque de non-détection de ces anomalies par le commissaire aux comptes.

h2a-nep-200:paragraphe-11:ligne-84

11. Le risque d’anomalies significatives dans les comptes est propre à l’entité ; il existe indépendamment de l’audit des comptes. Il se subdivise en risque inhérent et risque lié au contrôle.
Le risque inhérent correspond à la possibilité que, sans tenir compte du contrôle interne qui pourrait exister dans l’entité, une anomalie significative se produise dans les comptes.
Le risque lié au contrôle correspond au risque qu’une anomalie significative ne soit ni prévenue ni détectée par le contrôle interne de l’entité et donc non corrigée en temps voulu.

h2a-nep-200:paragraphe-12:ligne-87

12. Le risque de non-détection est propre à la mission d’audit : il correspond au risque que le commissaire aux comptes ne parvienne pas à détecter une anomalie significative.

h2a-nep-200:paragraphe-13:ligne-88

13. Le commissaire aux comptes réduit le risque d’audit à un niveau suffisamment faible pour obtenir l’assurance recherchée nécessaire à la certification des comptes.
A cette fin, il évalue le risque d’anomalies significatives et conçoit les procédures d’audit à mettre en œuvre en réponse à cette évaluation, conformément aux principes définis dans les normes d’exercice professionnel.
Plus le commissaire aux comptes évalue le risque d’anomalies significatives à un niveau élevé, plus il met en œuvre de procédures d’audit complémentaires afin de réduire le risque de non-détection.

## Seuil de signification (`seuil-signification-audit`)

### h2a-nep-320
https://h2a-france.org/normes/application-de-la-notion-de-caractere-significatif-lors-de-la-planification-et-de-la-realisation-dun-audit/

h2a-nep-320:paragraphe-06:ligne-70

06. Seuil de signification : montant au-delà duquel les décisions économiques ou le jugement fondé sur les comptes sont susceptibles d’être influencés.

h2a-nep-320:paragraphe-07:ligne-71

07. Seuil de planification : seuil d’un montant inférieur au seuil de signification utilisé par le commissaire aux comptes pour définir la nature et l’étendue de ses travaux. Le seuil de planification est fixé à un montant tel qu’il permet de réduire à un niveau acceptable le risque que le montant des anomalies relevées non corrigées et des anomalies non détectées excède le seuil de signification.
Notion de caractère significatif dans le contexte de l’audit

h2a-nep-320:paragraphe-09:ligne-74

09. Le commissaire aux comptes met en œuvre la notion de caractère significatif dans le contexte de l’audit des comptes en considérant non seulement le montant des anomalies mais aussi leur nature. Il prend également en compte les circonstances particulières de leur survenance : en effet, les circonstances entourant certaines anomalies peuvent amener le commissaire aux comptes à les juger significatives quand bien même leur montant ne le serait pas.

h2a-nep-320:paragraphe-12:ligne-81

12. Pour évaluer le caractère significatif d’une anomalie à partir de son montant, le commissaire aux comptes détermine un ou des seuils de signification.

h2a-nep-320:paragraphe-14:ligne-84

14. Lors de la planification de l’audit, le commissaire aux comptes détermine un seuil de signification au niveau des comptes pris dans leur ensemble.

h2a-nep-320:paragraphe-15:ligne-85

15. Si, dans le contexte spécifique à l’entité, il existe des flux d’opérations, soldes de comptes ou informations à fournir pour lesquels des anomalies de montant inférieur au seuil de signification fixé pour les comptes pris dans leur ensemble pourraient influencer le jugement des utilisateurs des comptes ou les décisions économiques qu’ils prennent en se fondant sur ceux-ci, le commissaire aux comptes apprécie s’il doit également fixer un ou des seuils de signification de montants inférieurs pour ces flux d’opérations, soldes de comptes ou informations à fournir.

h2a-nep-320:paragraphe-17:ligne-90

17. Sur la base de son jugement professionnel, le commissaire aux comptes identifie des critères pertinents à partir desquels, par application de taux ou d’autres modalités de calcul, il détermine le seuil ou les seuils de signification. Ces critères peuvent être, par exemple :
– le résultat courant ;
– le résultat net ;
– le chiffre d’affaires ;
– les capitaux propres ; ou
– l’endettement net.

h2a-nep-320:paragraphe-22:ligne-107

22. Au cours de la mission, le commissaire aux comptes reconsidère le seuil ou les seuils de signification s’il a la connaissance de faits nouveaux ou d’évolutions de l’entité qui remettent en cause l’évaluation initiale de ces seuils. Il peut en être ainsi, par exemple, lorsque la détermination du seuil ou des seuils a été faite à partir de prévisions dont les réalisations s’écartent sensiblement.

h2a-nep-320:paragraphe-24:ligne-110

24. Le commissaire aux comptes fait figurer dans son dossier le ou les seuils de signification et le ou les seuils de planification qu’il a retenus ainsi que les critères pris en compte pour les déterminer. Il fait également figurer dans son dossier toute modification apportée à ces montants au cours de l’audit et les explications y afférentes.

### dila-a821-70
https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048882384

dila-a821-70:paragraphe-6:ligne-10

 6. Seuil de signification : montant au-delà  duquel les décisions économiques ou le jugement fondé sur les comptes  sont susceptibles d'être influencés.

dila-a821-70:paragraphe-7:ligne-11

 7. Seuil de planification : seuil d'un montant  inférieur au seuil de signification utilisé par le commissaire aux  comptes pour définir la nature et l'étendue de ses travaux. Le seuil de  planification est fixé à un montant tel qu'il permet de réduire à un  niveau acceptable le risque que le montant des anomalies relevées non  corrigées et des anomalies non détectées excède le seuil de  signification.
Notion de caractère significatif dans le contexte de l'audit

dila-a821-70:paragraphe-9:ligne-14

 9. Le commissaire aux comptes met en œuvre la  notion de caractère significatif dans le contexte de l'audit des comptes  en considérant non seulement le montant des anomalies mais aussi leur  nature. Il prend également en compte les circonstances particulières de  leur survenance : en effet, les circonstances entourant certaines  anomalies peuvent amener le commissaire aux comptes à les juger  significatives quand bien même leur montant ne le serait pas.

dila-a821-70:paragraphe-14:ligne-24

 14. Lors de la planification de l'audit, le  commissaire aux comptes détermine un seuil de signification au niveau  des comptes pris dans leur ensemble.

dila-a821-70:paragraphe-15:ligne-25

 15. Si, dans le contexte spécifique à l'entité,  il existe des flux d'opérations, soldes de comptes ou informations à  fournir pour lesquels des anomalies de montant inférieur au seuil de  signification fixé pour les comptes pris dans leur ensemble pourraient  influencer le jugement des utilisateurs des comptes ou les décisions  économiques qu'ils prennent en se fondant sur ceux-ci, le commissaire  aux comptes apprécie s'il doit également fixer un ou des seuils de  signification de montants inférieurs pour ces flux d'opérations, soldes  de comptes ou informations à fournir.

dila-a821-70:paragraphe-17:ligne-30

 17. Sur la base de son jugement professionnel, le  commissaire aux comptes identifie des critères pertinents à partir  desquels, par application de taux ou d'autres modalités de calcul, il  détermine le seuil ou les seuils de signification. Ces critères peuvent  être, par exemple :
 ― le résultat courant ;
 ― le résultat net ;
 ― le chiffre d'affaires ;
 ― les capitaux propres ; ou
 ― l'endettement net.

dila-a821-70:paragraphe-24:ligne-51

 24. Le commissaire aux comptes fait figurer dans  son dossier le ou les seuils de signification et le ou les seuils de  planification qu'il a retenus ainsi que les critères pris en compte pour  les déterminer. Il fait également figurer dans son dossier toute  modification apportée à ces montants au cours de l'audit et les  explications y afférentes.

## Seuil de planification (`seuil-planification-audit`)

### h2a-nep-320
https://h2a-france.org/normes/application-de-la-notion-de-caractere-significatif-lors-de-la-planification-et-de-la-realisation-dun-audit/

h2a-nep-320:paragraphe-07:ligne-71

07. Seuil de planification : seuil d’un montant inférieur au seuil de signification utilisé par le commissaire aux comptes pour définir la nature et l’étendue de ses travaux. Le seuil de planification est fixé à un montant tel qu’il permet de réduire à un niveau acceptable le risque que le montant des anomalies relevées non corrigées et des anomalies non détectées excède le seuil de signification.
Notion de caractère significatif dans le contexte de l’audit

h2a-nep-320:paragraphe-09:ligne-74

09. Le commissaire aux comptes met en œuvre la notion de caractère significatif dans le contexte de l’audit des comptes en considérant non seulement le montant des anomalies mais aussi leur nature. Il prend également en compte les circonstances particulières de leur survenance : en effet, les circonstances entourant certaines anomalies peuvent amener le commissaire aux comptes à les juger significatives quand bien même leur montant ne le serait pas.

h2a-nep-320:paragraphe-19:ligne-103

19. Lors de la planification de l’audit, le commissaire aux comptes détermine un ou des seuil(s) de planification de la mission.

h2a-nep-320:paragraphe-20:ligne-104

20. La détermination du seuil de planification ne relève pas du seul calcul arithmétique mais également du jugement professionnel. Lorsqu’il détermine ce seuil, le commissaire aux comptes s’appuie sur la connaissance qu’il a de l’entité, mise à jour au cours de la mise en œuvre des procédures d’évaluation des risques, et prend en compte le risque d’anomalies dans les comptes de l’exercice en cours au vu, notamment, de la nature et de l’étendue des anomalies relevées au cours des audits précédents. Le seuil de planification est inférieur au seuil de signification. Il est généralement déterminé en appliquant un pourcentage à ce dernier.

h2a-nep-320:paragraphe-21:ligne-105

21. Si le commissaire aux comptes a estimé nécessaire de fixer un ou des seuils de signification de montants inférieurs pour certains flux d’opérations, soldes de comptes ou informations, il détermine pour ce ou chacun de ces seuils de signification un seuil de planification.
Modification des seuils de signification ou de planification au cours de la mission

h2a-nep-320:paragraphe-24:ligne-110

24. Le commissaire aux comptes fait figurer dans son dossier le ou les seuils de signification et le ou les seuils de planification qu’il a retenus ainsi que les critères pris en compte pour les déterminer. Il fait également figurer dans son dossier toute modification apportée à ces montants au cours de l’audit et les explications y afférentes.

### dila-a821-70
https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048882384

dila-a821-70:paragraphe-7:ligne-11

 7. Seuil de planification : seuil d'un montant  inférieur au seuil de signification utilisé par le commissaire aux  comptes pour définir la nature et l'étendue de ses travaux. Le seuil de  planification est fixé à un montant tel qu'il permet de réduire à un  niveau acceptable le risque que le montant des anomalies relevées non  corrigées et des anomalies non détectées excède le seuil de  signification.
Notion de caractère significatif dans le contexte de l'audit

dila-a821-70:paragraphe-19:ligne-43

 19. Lors de la planification de l'audit, le  commissaire aux comptes détermine un ou des seuil(s) de planification de  la mission.

dila-a821-70:paragraphe-20:ligne-44

20. La détermination du seuil de planification ne  relève pas du seul calcul arithmétique mais également du jugement  professionnel. Lorsqu'il détermine ce seuil, le commissaire aux comptes  s'appuie sur la connaissance qu'il a de l'entité, mise à jour au cours  de la mise en œuvre des procédures d'évaluation des risques, et prend en  compte le risque d'anomalies dans les comptes de l'exercice en cours au  vu, notamment, de la nature et de l'étendue des anomalies relevées au  cours des audits précédents. Le seuil de planification est inférieur au  seuil de signification. Il est généralement déterminé en appliquant un  pourcentage à ce dernier.

dila-a821-70:paragraphe-24:ligne-51

 24. Le commissaire aux comptes fait figurer dans  son dossier le ou les seuils de signification et le ou les seuils de  planification qu'il a retenus ainsi que les critères pris en compte pour  les déterminer. Il fait également figurer dans son dossier toute  modification apportée à ces montants au cours de l'audit et les  explications y afférentes.

## Contrôle interne (`controle-interne-audit`)

### h2a-nep-315
https://h2a-france.org/normes/connaissance-de-lentite-et-de-son-environnement-et-evaluation-du-risque-danomalies-significatives-dans-les-comptes/

h2a-nep-315:paragraphe-24:ligne-130

24. Pour les besoins des normes d’exercice professionnel, le contrôle interne s’entend comme un ensemble de moyens, de comportements, de procédures et d’actions, conçu, mis en oeuvre et suivi par l’entité, et adapté à ses caractéristiques propres. Ainsi, le contrôle interne de l’entité :
• contribue à la maîtrise de ses activités, à l’efficacité de ses opérations et à l’utilisation efficiente de ses ressources ; et
• doit lui permettre de prendre en compte de manière appropriée les risques significatifs, qu’ils soient opérationnels, financiers ou de conformité.
Le contrôle interne vise plus particulièrement à assurer :
• la conformité aux lois et règlements ;
• l’application des instructions et des orientations fixées par la direction ;
• le bon fonctionnement des processus internes de l’entité, notamment ceux concourant à la sauvegarde de ses actifs ;
• la fiabilité des informations financières.
Le contrôle interne comporte les cinq composantes intégrées suivantes :
• l’environnement de contrôle, qui résulte du comportement des organes mentionnés à l’article L. 821-63 du code de commerce et de la direction, comprenant leur degré de sensibilité à l’éthique, à la transparence et à la fiabilité de l’information financière, ainsi que les actions que ceux-ci mènent en matière de contrôle interne aux différents niveaux de l’organisation de l’entité ;
• le processus d’évaluation des risques, qui est utilisé par l’entité pour identifier les risques liés à son activité et pertinents au regard de l’information financière, pour décider des mesures à prendre afin de répondre à ces risques et suivre les résultats de ces mesures ;
• le pilotage du contrôle interne, qui correspond aux évaluations réalisées par l’entité pour s’assurer de l’efficacité du contrôle interne, incluant l’évaluation de la conception et du fonctionnement des contrôles en temps opportun et la mise en oeuvre des éventuelles mesures correctives nécessaires ;
• le système d’information de l’entité et de communication interne et externe relatifs aux éléments importants pour la préparation des comptes ;
• les activités de contrôle, qui se traduisent par la mise en oeuvre effective des procédures de traitement des risques identifiés par l’entité, et qui permettent de s’assurer que les directives de la direction sont respectées dans toutes les autres composantes du contrôle interne.
La prise de connaissance et l’appréciation des cinq composantes du contrôle interne de l’entité porte sur les éléments relatifs à la préparation des comptes
Environnement de contrôle

h2a-nep-315:paragraphe-34:ligne-190

34. Pour chaque contrôle identifié et pour les contrôles généraux informatiques permettant de répondre aux risques liés à l’environnement informatique, le commissaire aux comptes :
• apprécie si la conception du contrôle est efficace pour répondre au risque d’anomalies significatives au niveau des assertions ou pour permettre le fonctionnement d’autres contrôles ;
• détermine si le contrôle a été mis en oeuvre en réalisant des procédures complémentaires à ses demandes d’information auprès du personnel de l’entité et, à l’issue de ces procédures, confirme ou infirme son intention de s’appuyer sur le contrôle.
Faiblesses du contrôle interne de l’entité

h2a-nep-315:paragraphe-41:ligne-215

41. L’appréciation par le commissaire aux comptes des composantes du contrôle interne, notamment des activités de contrôle, lui permet de disposer d’une analyse préliminaire de la conception et de la mise en oeuvre du contrôle interne de l’entité.
Si, en fonction de cette appréciation et à l’issue des travaux mis en oeuvre conformément au paragraphe 33, le commissaire aux comptes prévoit de s’appuyer sur les contrôles pertinents pour sa mission et/ou les procédures de substance, à elles seules, ne permettent pas de collecter les éléments suffisants et appropriés pour répondre au risque d’anomalies significatives au niveau des assertions, il évalue le risque lié au contrôle.
Si, à l’issue de cette évaluation, il estime pouvoir s’appuyer effectivement sur ces contrôles, il teste l’efficacité de leur fonctionnement dans le cadre de sa réponse à l’évaluation du risque d’anomalies significatives au niveau des assertions, conformément aux principes définis dans la norme d’exercice professionnel « Procédures d’audit mises en oeuvre par le commissaire aux comptes à l’issue de sa prise de connaissance de l’entité et de son environnement et de son évaluation du risque d’anomalies significatives dans les comptes ».
Lorsqu’il ne teste pas l’efficacité du fonctionnement des contrôles, l’évaluation du risque d’anomalies significatives au niveau des assertions correspond à l’évaluation du risque inhérent.
Evaluation du caractère suffisant et approprié des éléments collectés

### dila-a821-72
https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000054151014

dila-a821-72:paragraphe-24:ligne-70

 24. Pour les besoins des normes d'exercice professionnel, le contrôle interne s'entend comme un ensemble de moyens, de comportements, de procédures et d'actions, conçu, mis en œuvre et suivi par l'entité, et adapté à ses caractéristiques propres. Ainsi, le contrôle interne de l'entité :
 • contribue à la maîtrise de ses activités, à l'efficacité de ses opérations et à l'utilisation efficiente de ses ressources ; et
 • doit lui permettre de prendre en compte de manière appropriée les risques significatifs, qu'ils soient opérationnels, financiers ou de conformité.
 Le contrôle interne vise plus particulièrement à assurer :
 • la conformité aux lois et règlements ;
 • l'application des instructions et des orientations fixées par la direction ;
 • le bon fonctionnement des processus internes de l'entité, notamment ceux concourant à la sauvegarde de ses actifs ;
 • la fiabilité des informations financières.
 Le contrôle interne comporte les cinq composantes intégrées suivantes :
 • l'environnement de contrôle, qui résulte du comportement des organes mentionnés à l'article L. 821-63 du code de commerce et de la direction, comprenant leur degré de sensibilité à l'éthique, à la transparence et à la fiabilité de l'information financière, ainsi que les actions que ceux-ci mènent en matière de contrôle interne aux différents niveaux de l'organisation de l'entité ;
 • le processus d'évaluation des risques, qui est utilisé par l'entité pour identifier les risques liés à son activité et pertinents au regard de l'information financière, pour décider des mesures à prendre afin de répondre à ces risques et suivre les résultats de ces mesures ;
 • le pilotage du contrôle interne, qui correspond aux évaluations réalisées par l'entité pour s'assurer de l'efficacité du contrôle interne, incluant l'évaluation de la conception et du fonctionnement des contrôles en temps opportun et la mise en œuvre des éventuelles mesures correctives nécessaires ;
 • le système d'information de l'entité et de communication interne et externe relatifs aux éléments importants pour la préparation des comptes ;
 • les activités de contrôle, qui se traduisent par la mise en œuvre effective des procédures de traitement des risques identifiés par l'entité, et qui permettent de s'assurer que les directives de la direction sont respectées dans toutes les autres composantes du contrôle interne.
 La prise de connaissance et l'appréciation des cinq composantes du contrôle interne de l'entité porte sur les éléments relatifs à la préparation des comptes.
 Environnement de contrôle

dila-a821-72:paragraphe-34:ligne-130

 34. Pour chaque contrôle identifié et pour les contrôles généraux informatiques permettant de répondre aux risques liés à l'environnement informatique, le commissaire aux comptes :
 • apprécie si la conception du contrôle est efficace pour répondre au risque d'anomalies significatives au niveau des assertions ou pour permettre le fonctionnement d'autres contrôles ;
 • détermine si le contrôle a été mis en œuvre en réalisant des procédures complémentaires à ses demandes d'information auprès du personnel de l'entité et, à l'issue de ces procédures, confirme ou infirme son intention de s'appuyer sur le contrôle.
 Faiblesses du contrôle interne de l'entité

dila-a821-72:paragraphe-41:ligne-155

 41. L'appréciation par le commissaire aux comptes des composantes du contrôle interne, notamment des activités de contrôle, lui permet de disposer d'une analyse préliminaire de la conception et de la mise en œuvre du contrôle interne de l'entité.
 Si, en fonction de cette appréciation et à l'issue des travaux mis en œuvre conformément au paragraphe 33, le commissaire aux comptes prévoit de s'appuyer sur les contrôles pertinents pour sa mission et/ou les procédures de substance, à elles seules, ne permettent pas de collecter les éléments suffisants et appropriés pour répondre au risque d'anomalies significatives au niveau des assertions, il évalue le risque lié au contrôle.
 Si, à l'issue de cette évaluation, il estime pouvoir s'appuyer effectivement sur ces contrôles, il teste l'efficacité de leur fonctionnement dans le cadre de sa réponse à l'évaluation du risque d'anomalies significatives au niveau des assertions, conformément aux principes définis dans la norme d'exercice professionnel "Procédures d'audit mises en œuvre par le commissaire aux comptes à l'issue de sa prise de connaissance de l'entité et de son environnement et de son évaluation du risque d'anomalies significatives dans les comptes".
 Lorsqu'il ne teste pas l'efficacité du fonctionnement des contrôles, l'évaluation du risque d'anomalies significatives au niveau des assertions correspond à l'évaluation du risque inhérent.
 Evaluation du caractère suffisant et approprié des éléments collectés

## Informations produites par l’entité (IPE) (`ipe-audit`)

### h2a-nep-500
https://h2a-france.org/normes/caractere-probant-des-elements-collectes/

h2a-nep-500:paragraphe-05:ligne-70

05. Ces éléments apportent au commissaire aux comptes des éléments de preuves ou des présomptions quant au respect d’une ou plusieurs assertions. Ces éléments doivent être suffisants et appropriés pour lui permettre de fonder son opinion sur les comptes.

h2a-nep-500:paragraphe-06:ligne-71

06. Le caractère approprié est fonction de la qualité des éléments collectés, c’est-à-dire de leur fiabilité et de leur pertinence.
Le caractère suffisant s’apprécie par rapport à la quantité d’éléments collectés. La quantité d’éléments à collecter dépend du risque d’anomalies significatives mais aussi de la qualité des éléments collectés. Le degré de fiabilité des éléments collectés dépend de leur origine, de leur nature et des circonstances particulières dans lesquelles ils ont été recueillis. Ainsi, en principe :
– les éléments collectés d’origine externe sont plus fiables que ceux d’origine interne. Pour cette raison, lorsque le commissaire aux comptes utilise des informations produites par l’entité pour mettre en œuvre des procédures d’audit, il collecte des éléments concernant leur exactitude et leur exhaustivité ;
– les éléments collectés d’origine interne sont d’autant plus fiables que le contrôle interne est efficace ;
– les éléments obtenus directement par le commissaire aux comptes, par exemple lors d’une observation physique, sont plus fiables que ceux obtenus par des demandes d’information ;
– les éléments collectés sont plus fiables lorsqu’ils sont étayés par des documents ;
– enfin, les éléments collectés constitués de documents originaux sont plus fiables que ceux constitués de copies.

h2a-nep-500:paragraphe-07:ligne-78

07. Dans le cadre de son appréciation de la fiabilité des éléments collectés, le commissaire aux comptes garde un esprit critique quant aux indices qui pourraient remettre en cause leur validité. En cas de doute, il mène plus avant ses investigations.
Ainsi, lorsqu’un élément collecté n’est pas cohérent par rapport à un autre, le commissaire aux comptes détermine les procédures d’audit complémentaires à mettre en place pour élucider cette incohérence.

### dila-a821-74
https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000048882102

dila-a821-74:paragraphe-5:ligne-10

5. Ces éléments apportent au commissaire aux comptes des éléments de preuves ou des présomptions quant au respect d'une ou plusieurs assertions. Ces éléments doivent être suffisants et appropriés pour lui permettre de fonder son opinion sur les comptes.

dila-a821-74:paragraphe-6:ligne-11

6. Le caractère approprié est fonction de la qualité des éléments collectés, c'est-à-dire de leur fiabilité et de leur pertinence.
Le caractère suffisant s'apprécie par rapport à la quantité d'éléments collectés. La quantité d'éléments à collecter dépend du risque d'anomalies significatives mais aussi de la qualité des éléments collectés. Le degré de fiabilité des éléments collectés dépend de leur origine, de leur nature et des circonstances particulières dans lesquelles ils ont été recueillis. Ainsi, en principe :
― les éléments collectés d'origine externe sont plus fiables que ceux d'origine interne. Pour cette raison, lorsque le commissaire aux comptes utilise des informations produites par l'entité pour mettre en œuvre des procédures d'audit, il collecte des éléments concernant leur exactitude et leur exhaustivité ;
- les éléments collectés d'origine interne sont d'autant plus fiables que le contrôle interne est efficace ;
- les éléments obtenus directement par le commissaire aux comptes, par exemple lors d'une observation physique, sont plus fiables que ceux obtenus par des demandes d'information ;
- les éléments collectés sont plus fiables lorsqu'ils sont étayés par des documents ;
- enfin, les éléments collectés constitués de documents originaux sont plus fiables que ceux constitués de copies.

dila-a821-74:paragraphe-7:ligne-18

7. Dans le cadre de son appréciation de la fiabilité des éléments collectés, le commissaire aux comptes garde un esprit critique quant aux indices qui pourraient remettre en cause leur validité. En cas de doute, il mène plus avant ses investigations.
Ainsi, lorsqu'un élément collecté n'est pas cohérent par rapport à un autre, le commissaire aux comptes détermine les procédures d'audit complémentaires à mettre en place pour élucider cette incohérence.

### h2a-nep-315
https://h2a-france.org/normes/connaissance-de-lentite-et-de-son-environnement-et-evaluation-du-risque-danomalies-significatives-dans-les-comptes/

h2a-nep-315:paragraphe-46:ligne-230

46. Conformément aux dispositions de la norme d’exercice professionnel « Caractère probant des éléments collectés », lorsque le commissaire aux comptes a recours à des outils et techniques automatisés pour l’aider à identifier et évaluer le risque d’anomalies significatives, il apprécie, en exerçant son esprit critique, si les outils permettent d’atteindre l’objectif poursuivi par les procédures d’audit relatives à l’identification et l’évaluation du risque d’anomalies significatives. Pour ce faire, il apprécie :
• la manière dont les outils fonctionnent ; et
• le degré de pertinence et de fiabilité des informations qui sont intégrées dans ces outils.
Echanges d’informations au sein de l’équipe d’audit
