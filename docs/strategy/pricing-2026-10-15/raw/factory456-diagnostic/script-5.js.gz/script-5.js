
(function(){
 // Catalogue des automatisations standard (Notion « Catalogue des automatisations — Cabinets comptables »), hors lignes à l'étude.
 var ETAPES=[['relation','Entrée en relation'],['collecte','Collecte'],['saisie','Saisie'],['cloture','Clôture'],['conseil','Conseil'],['cabinet','GI'],['migration','Migrations & reprises']];
 var PROCS=[
  {"code":"lcbft","e":"relation","l":"Entrée en relation et conformité LCB-FT","d":"Portail sécurisé, signature, vérification d’identité et des bénéficiaires effectifs","t":"juridique","soft":["Pappers","Yousign"],"f":"Mensuel","m":45},
  {"code":"lm","e":"relation","l":"Lettre de mission et conformité du dossier","d":"Génération de la lettre de mission, suivi de la conformité du dossier client","t":"juridique","soft":["GED","Signature électronique"],"f":"Annuel","m":30},
  {"code":"devis","e":"relation","l":"Proposition de mission et devis","d":"Devis établi depuis la fiche prospect et la grille tarifaire, lettre de mission générée dans la foulée","t":"juridique","soft":["Odoo","Sellsy","Word"],"f":"Mensuel","m":40},
  {"code":"onboard_client","e":"relation","l":"Création du dossier client dans les outils","d":"Dossier créé dans la compta, la paie, la GED et le portail, paramétrage cohérent partout","t":"compta","soft":["ACD","Cegid Expert","Cegid Loop","GED"],"f":"Mensuel","m":60},
  {"code":"mandats","e":"relation","l":"Mandats EDI, EFI, TDFC et DSN","d":"Adhésions et mandats déposés et suivis auprès de la DGFiP et de net-entreprises","t":"compta","soft":["impots.gouv","Net-entreprises","JeDeclare"],"f":"Mensuel","m":30},
  {"code":"habilitations","e":"relation","l":"Audit des habilitations fiscales EDI / EFI","d":"Mandats actifs, inactifs et manquants détectés dossier par dossier, utile à la reprise d’un portefeuille","t":"compta","soft":["impots.gouv"],"f":"Annuel","m":10},
  {"code":"opendata","e":"relation","l":"Enrichissement des fiches clients (INPI, open data)","d":"Dirigeants, effectif, NAF, statut, actes déposés complétés automatiquement","t":"juridique","soft":["INPI / RNE","Pappers","Infogreffe"],"f":"Mensuel","m":5},
  {"code":"kyc_maj","e":"relation","l":"Revue annuelle LCB-FT et bénéficiaires effectifs","d":"Fiches clients réévaluées, pièces expirées réclamées, registre des bénéficiaires mis à jour","t":"juridique","soft":["Pappers","INPI / RNE"],"f":"Annuel","m":20},
  {"code":"arbo_ged","e":"relation","l":"Arborescence GED du nouveau dossier","d":"Dossiers et sous-dossiers créés selon le plan de classement du cabinet, droits posés","t":"ged","soft":["SharePoint","Zeendoc","Welyb"],"f":"Mensuel","m":15},
  {"code":"reprise_dossier","e":"relation","l":"Reprise d’un dossier venant d’un autre cabinet","d":"Pièces demandées au confrère, balance d’entrée contrôlée, à-nouveaux passés","t":"compta","soft":["ACD","Cegid Expert","Cegid Loop"],"f":"Mensuel","m":90},
  {"code":"paie_var","e":"collecte","l":"Collecte des variables de paie","d":"Demande et collecte par e-mail, SMS ou WhatsApp, chargement dans la paie","t":"social","soft":["Silae"],"f":"Mensuel","m":15},
  {"code":"juri_info","e":"collecte","l":"Collecte des informations juridiques","d":"Affectation du résultat, conventions… pour le juridique annuel","t":"juridique","soft":["Outlook","GED"],"f":"Annuel","m":20},
  {"code":"pieces","e":"collecte","l":"Récupération et intégration des pièces scannées","d":"Pièces comptables récupérées et intégrées automatiquement dans le dossier","t":"compta","soft":["Agiris ISACOMPTA","ACD"],"f":"Hebdomadaire","m":20},
  {"code":"relances","e":"collecte","l":"Demande d’information et relances clients","d":"Pièces et informations manquantes réclamées avec escalade J+7, J+14, J+21","t":"com","soft":["Outlook","GED"],"f":"Mensuel","m":10},
  {"code":"factures_pa","e":"collecte","l":"Collecte des factures sur les plateformes agréées","d":"E-factures récupérées sur les plateformes et l’annuaire, contrôlées et déposées dans le dossier","t":"compta","soft":["Annuaire facturation électronique","Pennylane","Tiime"],"f":"Hebdomadaire","m":10},
  {"code":"ecommerce_pieces","e":"collecte","l":"Collecte des ventes et pièces e-commerce","d":"Commandes, factures, avoirs, frais de plateforme et relevés de versements récupérés sur Shopify, Amazon, WooCommerce, PrestaShop, Stripe, PayPal… et déposés dans le dossier","t":"compta","soft":["Shopify","Amazon Seller Central","WooCommerce","PrestaShop","Stripe","PayPal"],"f":"Mensuel","m":30},
  {"code":"releves_pdf","e":"collecte","l":"Récupération des relevés bancaires sur les portails","d":"Relevés PDF téléchargés sur les espaces bancaires quand le flux EBICS n’est pas en place","t":"compta","soft":["Espaces bancaires"],"f":"Mensuel","m":10},
  {"code":"factures_portails","e":"collecte","l":"Téléchargement des factures fournisseurs récurrentes","d":"EDF, Orange, Amazon, loyers… récupérées sur les espaces fournisseurs et déposées dans le dossier","t":"compta","soft":["Espaces fournisseurs","GED"],"f":"Mensuel","m":15},
  {"code":"caisse_z","e":"collecte","l":"Récupération des tickets Z de caisse","d":"Z de caisse collectés (mail, portail, export) et rapprochés jour par jour","t":"compta","soft":["Logiciels de caisse"],"f":"Mensuel","m":15},
  {"code":"notes_frais","e":"collecte","l":"Collecte des notes de frais et justificatifs","d":"Notes de frais demandées, justificatifs vérifiés, tableau prêt pour la saisie","t":"compta","soft":["Outlook","GED"],"f":"Mensuel","m":10},
  {"code":"docs_sociaux","e":"collecte","l":"Collecte des documents sociaux","d":"Contrats, avenants, arrêts de travail, mutuelle… réclamés et classés dans le dossier salarié","t":"social","soft":["Silae","GED"],"f":"Mensuel","m":10},
  {"code":"attest_urssaf","e":"collecte","l":"Attestations de vigilance et de régularité","d":"Attestations URSSAF et fiscales téléchargées et transmises aux donneurs d’ordre","t":"social","soft":["URSSAF","impots.gouv"],"f":"Trimestriel","m":10},
  {"code":"inventaire","e":"collecte","l":"Collecte des inventaires et stocks de fin d’exercice","d":"Tableaux d’inventaire demandés, contrôlés et valorisés pour la clôture","t":"compta","soft":["Excel","Outlook"],"f":"Annuel","m":20},
  {"code":"avis_fiscaux","e":"collecte","l":"Récupération des avis fiscaux (TF, CFE, IR, IS)","d":"Avis collectés sur impots.gouv, nommés et classés par dossier, montants et échéances consolidés","t":"compta","soft":["impots.gouv","GED"],"f":"Annuel","m":10},
  {"code":"messageries","e":"collecte","l":"Surveillance des messageries impots.gouv et URSSAF","d":"Messages de tous les dossiers centralisés, non lus et critiques remontés en priorité","t":"compta","soft":["impots.gouv","URSSAF"],"f":"Hebdomadaire","m":5},
  {"code":"edi_juri","e":"saisie","l":"Intégration EDI dans le logiciel juridique","d":"Fichiers EDI intégrés automatiquement","t":"juridique","soft":[],"f":"Annuel","m":15},
  {"code":"presaisie","e":"saisie","l":"Pré-saisie des factures fournisseurs","d":"OCR, extraction, proposition d’imputation, validation en un clic","t":"compta","soft":["Sage Génération Experts","Cegid Expert","Cegid Loop","ACD"],"f":"Hebdomadaire","m":20},
  {"code":"banque","e":"saisie","l":"Intégration bancaire","d":"Relevés télécollectés et écritures intégrées dans le dossier","t":"compta","soft":["ACD"],"f":"Hebdomadaire","m":15},
  {"code":"ventes","e":"saisie","l":"Intégration des ventes et de la facturation client","d":"Journaux de ventes importés depuis l’outil de facturation du client, comptes clients tenus","t":"compta","soft":["Pennylane","Tiime","Sellsy","Axonaut"],"f":"Mensuel","m":20},
  {"code":"ecommerce_ventes","e":"saisie","l":"Intégration comptable des ventes e-commerce","d":"Ventes ventilées par taux de TVA et par pays (OSS), commissions et frais de plateforme comptabilisés, versements Stripe / PayPal / Amazon rapprochés de la banque","t":"compta","soft":["Shopify","Amazon Seller Central","Stripe","PayPal","ACD","Pennylane"],"f":"Mensuel","m":30},
  {"code":"caisse_saisie","e":"saisie","l":"Écritures de caisse et encaissements","d":"Journal de caisse généré depuis les Z, TVA ventilée, remises en banque rapprochées","t":"compta","soft":["ACD","Cegid Expert","Cegid Loop"],"f":"Mensuel","m":20},
  {"code":"od_paie","e":"saisie","l":"Intégration des écritures de paie","d":"Écritures Silae intégrées en comptabilité, dossier par dossier","t":"compta","soft":["Silae","ACD"],"f":"Mensuel","m":10},
  {"code":"lettrage","e":"saisie","l":"Lettrage automatique des comptes tiers","d":"Comptes clients et fournisseurs lettrés automatiquement","t":"compta","soft":["ACD"],"f":"Mensuel","m":15},
  {"code":"rapprochement","e":"saisie","l":"Rapprochement bancaire","d":"Écritures pointées, suspens identifiés et justifiés, état de rapprochement produit","t":"compta","soft":["ACD","Sage Génération Experts"],"f":"Mensuel","m":20},
  {"code":"immos","e":"saisie","l":"Registre des immobilisations et amortissements","d":"Fiches créées depuis les factures, dotations calculées, sorties enregistrées","t":"compta","soft":["ACD","Cegid Expert","Cegid Loop"],"f":"Annuel","m":30},
  {"code":"od_tva","e":"saisie","l":"Écritures de TVA et OD de fin de période","d":"OD de TVA, à-nouveaux et abonnements passés automatiquement après contrôle","t":"compta","soft":["ACD"],"f":"Mensuel","m":10},
  {"code":"doublons","e":"saisie","l":"Détection des doublons et anomalies de saisie","d":"Factures en double, montants incohérents, comptes d’attente signalés avant la clôture","t":"compta","soft":["ACD","Cegid Expert","Cegid Loop"],"f":"Mensuel","m":10},
  {"code":"cutoff","e":"saisie","l":"Cut-off : FNP, CCA, FAE, PCA","d":"Écritures de régularisation proposées depuis les factures et les contrats connus","t":"compta","soft":["ACD"],"f":"Annuel","m":45},
  {"code":"paie_bulletins","e":"saisie","l":"Établissement des bulletins de paie","d":"Variables intégrées, bulletins calculés et contrôlés avant validation","t":"social","soft":["Silae","Cegid Quadra Paie"],"f":"Mensuel","m":15},
  {"code":"paie_entrees_sorties","e":"saisie","l":"Entrées et sorties de salariés","d":"DPAE, contrat et mutuelle à l’entrée ; solde de tout compte et documents de fin de contrat","t":"social","soft":["Silae","Net-entreprises"],"f":"Mensuel","m":45},
  {"code":"paie_arrets","e":"saisie","l":"Arrêts de travail et IJSS","d":"Attestations de salaire, DSN événementielle, suivi des indemnités journalières","t":"social","soft":["Silae","Net-entreprises"],"f":"Mensuel","m":20},
  {"code":"tva","e":"cloture","l":"Déclarations de TVA","d":"Préparation et contrôle des déclarations à partir du dossier","t":"compta","soft":["Pennylane","Tiime"],"f":"Mensuel","m":20},
  {"code":"controles_balance","e":"cloture","l":"Contrôles de cohérence de la balance","d":"Soldes anormaux, comptes d’attente, TVA non soldée signalés avant la clôture","t":"compta","soft":["ACD","Sage Génération Experts"],"f":"Mensuel","m":10},
  {"code":"situations","e":"cloture","l":"Situations intermédiaires","d":"Situation trimestrielle ou semestrielle produite avec ses commentaires","t":"compta","soft":["ACD","Cegid Expert","Cegid Loop"],"f":"Trimestriel","m":60},
  {"code":"cloture","e":"cloture","l":"Clôture des dossiers comptables","d":"Contrôles, dossier de travail et éditions générés","t":"compta","soft":["ACD"],"f":"Annuel","m":120},
  {"code":"revision","e":"cloture","l":"Révision assistée","d":"Détection et suivi des points en suspens du dossier","t":"compta","soft":["ACD"],"f":"Annuel","m":90},
  {"code":"justif_comptes","e":"cloture","l":"Justification des comptes","d":"Comptes de bilan justifiés, pièces rattachées, dossier de révision alimenté","t":"compta","soft":["ACD"],"f":"Annuel","m":90},
  {"code":"revue","e":"cloture","l":"Revue analytique de pré-clôture","d":"Balances et grands livres comparés N à N-2, ratios, revue pré-rédigée","t":"compta","soft":["Cegid Expert","Cegid Loop","MyUnisoft"],"f":"Annuel","m":45},
  {"code":"liasse","e":"cloture","l":"Liasse fiscale et télédéclaration","d":"Liasse préparée depuis la balance, contrôles de cohérence, envoi EDI-TDFC","t":"compta","soft":["ACD","JeDeclare"],"f":"Annuel","m":60},
  {"code":"is","e":"cloture","l":"Acomptes et solde d’IS","d":"Acomptes calculés, relevés 2571 / 2572 préparés et télédéclarés","t":"compta","soft":["impots.gouv","JeDeclare"],"f":"Trimestriel","m":15},
  {"code":"cfe_cvae","e":"cloture","l":"CFE, CVAE et taxes annexes","d":"Déclarations et paiements préparés dossier par dossier, échéances suivies","t":"compta","soft":["impots.gouv"],"f":"Annuel","m":20},
  {"code":"das2","e":"cloture","l":"DAS2 et déclaration des honoraires","d":"Honoraires et commissions extraits du dossier, DAS2 générée et transmise","t":"compta","soft":["ACD","Net-entreprises"],"f":"Annuel","m":20},
  {"code":"fec","e":"cloture","l":"Génération et contrôle du FEC","d":"FEC produit, testé (structure, séquence, doublons) et archivé","t":"compta","soft":["ACD","Cegid Expert","Cegid Loop"],"f":"Annuel","m":15},
  {"code":"edi_flux","e":"cloture","l":"Suivi des flux EDI (JeDeclare)","d":"Flux suivis, déclarations en anomalie relancées","t":"compta","soft":["JeDeclare"],"f":"Mensuel","m":5},
  {"code":"dettes","e":"cloture","l":"Dettes fiscales et attestations de régularité","d":"Dettes IS, TVA, CFE consolidées par dossier ; attestations fiscales et sociales générées","t":"compta","soft":["impots.gouv","URSSAF"],"f":"Trimestriel","m":10},
  {"code":"tableau_bord","e":"cloture","l":"Tableaux de bord mensuels client","d":"Indicateurs et graphiques produits et envoyés automatiquement à chaque client","t":"compta","soft":["Pennylane","MyUnisoft","Power BI"],"f":"Mensuel","m":20},
  {"code":"dsn","e":"cloture","l":"Suivi et relance des DSN","d":"DSN en anomalie ou rejetées détectées et relancées","t":"social","soft":["Silae","Net-entreprises"],"f":"Mensuel","m":10},
  {"code":"dsn_events","e":"cloture","l":"DSN mensuelle et événementielles","d":"DSN contrôlées, transmises et retours traités pour chaque dossier","t":"social","soft":["Silae","Net-entreprises"],"f":"Mensuel","m":15},
  {"code":"envoi_bulletins","e":"cloture","l":"Diffusion des bulletins et documents de paie","d":"Bulletins déposés dans les coffres salariés, journaux et états transmis au client","t":"social","soft":["Silae","Coffre-fort numérique"],"f":"Mensuel","m":10},
  {"code":"actes","e":"cloture","l":"Génération des actes juridiques","d":"AG, PV et actes du juridique annuel","t":"juridique","soft":["GED"],"f":"Annuel","m":60},
  {"code":"depot_comptes","e":"cloture","l":"Vérification du dépôt des comptes au greffe","d":"Dossiers non déposés détectés sur tout le portefeuille, alerte avant échéance","t":"juridique","soft":["Infogreffe","INPI / RNE"],"f":"Annuel","m":10},
  {"code":"plaquettes","e":"cloture","l":"Plaquettes et signature électronique","d":"Plaquettes client, juridique, banque, CAC envoyées en signature","t":"ged","soft":["GED","Signature électronique"],"f":"Annuel","m":30},
  {"code":"archivage","e":"cloture","l":"Archivage du dossier annuel","d":"Dossier de travail, liasse et éditions archivés dans la GED avec leur durée de conservation","t":"ged","soft":["GED"],"f":"Annuel","m":20},
  {"code":"ir","e":"conseil","l":"Déclarations de revenus (IR)","d":"Zones reprises depuis l’IR pré-remplie et un fichier Excel","t":"compta","soft":["ACD"],"f":"Annuel","m":30},
  {"code":"ir_ifi","e":"conseil","l":"Récupération des déclarations IR / IFI pré-remplies","d":"Déclarations téléchargées depuis impots.gouv pour chaque client, authentification gérée","t":"compta","soft":["impots.gouv"],"f":"Annuel","m":5},
  {"code":"rdv_bilan","e":"conseil","l":"Préparation du rendez-vous bilan","d":"Synthèse commentée, graphiques et points de conseil prêts avant le rendez-vous","t":"compta","soft":["ACD","Power BI"],"f":"Annuel","m":45},
  {"code":"previsionnel","e":"conseil","l":"Prévisionnel et business plan","d":"Prévisionnel bâti depuis l’historique, hypothèses documentées, plan de financement","t":"compta","soft":["Excel","Logiciels de prévisionnel"],"f":"Annuel","m":120},
  {"code":"tresorerie","e":"conseil","l":"Suivi de trésorerie et prévisions","d":"Position de trésorerie consolidée depuis les banques, prévision à 13 semaines","t":"compta","soft":["Agicap","Pennylane","Espaces bancaires"],"f":"Mensuel","m":20},
  {"code":"remu_dirigeant","e":"conseil","l":"Optimisation de la rémunération du dirigeant","d":"Simulations salaire / dividendes et charges sociales mises à jour chaque année","t":"compta","soft":["Excel"],"f":"Annuel","m":45},
  {"code":"alertes_kpi","e":"conseil","l":"Alertes sur les indicateurs du client","d":"Marge, trésorerie, délais de paiement surveillés ; alerte au collaborateur et au client","t":"compta","soft":["Pennylane","MyUnisoft"],"f":"Mensuel","m":5},
  {"code":"pilotage_fiscal","e":"conseil","l":"Pilotage fiscal du portefeuille","d":"Échéances TVA, IS, CVAE, PAS, liasse et alertes critiques sur un tableau de bord, synchronisé chaque nuit","t":"compta","soft":["impots.gouv","URSSAF"],"f":"Mensuel","m":5},
  {"code":"aides","e":"conseil","l":"Détection des aides et subventions","d":"Dispositifs éligibles repérés par activité et territoire, dossiers pré-montés","t":"libre","soft":["Bases aides publiques"],"f":"Trimestriel","m":15},
  {"code":"cir_cii","e":"conseil","l":"Crédits d’impôt : CIR, CII, JEI, apprentissage","d":"Éligibilité détectée, justificatifs collectés, formulaires préparés","t":"compta","soft":["impots.gouv"],"f":"Annuel","m":60},
  {"code":"fe_conformite","e":"conseil","l":"Conformité facturation électronique","d":"Statut e-facturation par dossier, plateforme choisie, rattachements manquants, mandats en masse","t":"compta","soft":["Annuaire facturation électronique","Jesignexpert"],"f":"Mensuel","m":10},
  {"code":"controle_fiscal","e":"conseil","l":"Préparation d’un contrôle fiscal ou URSSAF","d":"Pièces rassemblées, FEC vérifié, réponses aux demandes préparées","t":"compta","soft":["GED","impots.gouv"],"f":"Annuel","m":120},
  {"code":"veille","e":"conseil","l":"Veille légale et risques clients","d":"BODACC, procédures collectives et bénéficiaires effectifs surveillés, alertes par dossier","t":"juridique","soft":["BODACC","INPI / RNE"],"f":"Mensuel","m":5},
  {"code":"temps","e":"conseil","l":"Suivi des temps et budgets","d":"Temps et budgets des missions du cabinet suivis automatiquement","t":"libre","soft":[],"f":"Mensuel","m":5},
  {"code":"facturation_honoraires","e":"cabinet","l":"Facturation des honoraires","d":"Factures générées selon la lettre de mission et les temps, envoi et prélèvement","t":"libre","soft":["Odoo","Sellsy","Pennylane"],"f":"Mensuel","m":10},
  {"code":"recouvrement","e":"cabinet","l":"Relance des honoraires impayés","d":"Relances graduées, règlements rapprochés, suspension de mission signalée","t":"libre","soft":["Odoo","Outlook"],"f":"Mensuel","m":5},
  {"code":"planning","e":"cabinet","l":"Planning de production et suivi de charge","d":"Échéances de tous les dossiers planifiées, retards et surcharges signalés","t":"libre","soft":["Excel","Notion","Teams"],"f":"Hebdomadaire","m":5},
  {"code":"suivi_echeances","e":"cabinet","l":"Suivi des échéances déclaratives","d":"Calendrier fiscal et social du portefeuille consolidé, retards relancés","t":"compta","soft":["impots.gouv","JeDeclare"],"f":"Hebdomadaire","m":5},
  {"code":"qualite","e":"cabinet","l":"Contrôle qualité des dossiers","d":"Check-lists normées vérifiées, dossiers non conformes signalés au superviseur","t":"libre","soft":["GED"],"f":"Mensuel","m":10},
  {"code":"reporting_cabinet","e":"cabinet","l":"Tableau de bord du cabinet","d":"Production, temps et rentabilité par dossier et par collaborateur, chaque semaine","t":"libre","soft":["Power BI","Excel"],"f":"Hebdomadaire","m":5},
  {"code":"ged","e":"cabinet","l":"Classement GED intelligent","d":"Éditions mensuelles et annuelles classées dans la GED","t":"ged","soft":[],"f":"Mensuel","m":10},
  {"code":"courrier","e":"cabinet","l":"Courrier entrant numérisé et routé","d":"Courrier scanné, reconnu, rattaché au dossier et au collaborateur","t":"ged","soft":["Scanner","GED"],"f":"Quotidien","m":2},
  {"code":"signatures_masse","e":"cabinet","l":"Envoi en signature électronique en masse","d":"Lettres de mission, mandats et PV envoyés en lot et suivis jusqu’au retour","t":"ged","soft":["Yousign","Jesignexpert","DocuSign"],"f":"Mensuel","m":5},
  {"code":"mails","e":"cabinet","l":"Gestion des e-mails du cabinet","d":"Tri, classement, routage, propositions de réponse et relances","t":"com","soft":["Outlook","Gmail"],"f":"Quotidien","m":5},
  {"code":"reponses_clients","e":"cabinet","l":"Réponses aux questions clients courantes","d":"Questions simples (échéances, documents, accès) traitées avec relecture du collaborateur","t":"com","soft":["Outlook","WhatsApp"],"f":"Quotidien","m":3},
  {"code":"kb","e":"cabinet","l":"Base de connaissances interne","d":"Procédures, doctrine et modèles interrogés en langage naturel","t":"libre","soft":[],"f":"Quotidien","m":5},
  {"code":"support","e":"cabinet","l":"Agents support : RH, marketing, organisation","d":"Offres d’emploi, entretiens, comptes rendus et tâches","t":"libre","soft":[],"f":"Hebdomadaire","m":30},
  {"code":"apps","e":"cabinet","l":"Portails et applis générés par IA","d":"Portails clients, formulaires et petites applis métier en quelques heures","t":"libre","soft":[],"f":"Annuel","m":60},
  {"code":"mig_ged","e":"migration","l":"Migration de GED","d":"Documents, arborescence et métadonnées repris de l’ancienne GED vers la nouvelle, écarts contrôlés","t":"ged","soft":["SharePoint","Zeendoc","Welyb","MyCompanyFiles"],"f":"Ponctuel (une fois)","m":45},
  {"code":"mig_compta","e":"migration","l":"Migration de logiciel comptable","d":"Plans, tiers, historiques et à-nouveaux repris dossier par dossier, balances rapprochées","t":"compta","soft":["ACD","Cegid Expert","Cegid Loop","Pennylane","MyUnisoft"],"f":"Ponctuel (une fois)","m":90},
  {"code":"mig_paie","e":"migration","l":"Migration de logiciel de paie","d":"Salariés, contrats, cumuls et paramétrages repris, bulletins de contrôle comparés","t":"social","soft":["Silae","Cegid Quadra Paie","Openpaye"],"f":"Ponctuel (une fois)","m":60},
  {"code":"mig_juridique","e":"migration","l":"Migration du logiciel juridique","d":"Sociétés, dirigeants, historiques d’actes et registres repris","t":"juridique","soft":["Polyacte","SECIB","Jesignexpert"],"f":"Ponctuel (une fois)","m":45},
  {"code":"mig_portefeuille","e":"migration","l":"Reprise ou fusion d’un portefeuille de dossiers","d":"Dossiers du cabinet repris créés dans les outils, mandats transférés, pièces reprises","t":"compta","soft":["ACD","GED","impots.gouv"],"f":"Ponctuel (une fois)","m":120},
  {"code":"mig_fe","e":"migration","l":"Raccordement à la facturation électronique en masse","d":"Plateforme choisie, comptes et mandats créés, chaque dossier rattaché et vérifié","t":"compta","soft":["Annuaire facturation électronique","Pennylane","Tiime"],"f":"Ponctuel (une fois)","m":30},
  {"code":"mig_parametrage","e":"migration","l":"Paramétrage en masse des dossiers","d":"Nouveau plan de comptes, journaux et modèles d’écritures appliqués à tout le portefeuille","t":"compta","soft":["ACD","Cegid Expert","Cegid Loop"],"f":"Ponctuel (une fois)","m":20},
  {"code":"mig_banque","e":"migration","l":"Mise en place des flux bancaires EBICS","d":"Contrats signés, comptes rattachés, premiers relevés contrôlés pour chaque dossier","t":"compta","soft":["Espaces bancaires","ACD"],"f":"Ponctuel (une fois)","m":20},
  {"code":"mig_numerisation","e":"migration","l":"Numérisation et reprise de l’historique papier","d":"Archives scannées, reconnues et classées dans la GED par dossier et par exercice","t":"ged","soft":["Scanner","GED"],"f":"Ponctuel (une fois)","m":60},
  {"code":"mig_portail","e":"migration","l":"Déploiement d’un portail client","d":"Comptes créés pour tous les clients, documents initiaux déposés, invitations envoyées","t":"com","soft":["Welyb","MyCompanyFiles"],"f":"Ponctuel (une fois)","m":15},
  {"code":"mig_ops","e":"migration","l":"Changement d’organisme de prévoyance ou de retraite","d":"Affiliations et paramétrages de paie mis à jour pour chaque dossier, DSN contrôlées","t":"social","soft":["Silae","Net-entreprises"],"f":"Ponctuel (une fois)","m":20}
 ,
  {"code":"paie_conges","e":"saisie","l":"Congés, absences et notes de frais salariés","d":"Demandes collectées sur le portail RH, validées et intégrées dans la paie","t":"social","soft":["Silae","Lucca"],"f":"Mensuel","m":20},
  {"code":"mutuelle_prevoyance","e":"saisie","l":"Affiliations mutuelle et prévoyance","d":"Adhésions, radiations et changements de situation transmis aux organismes","t":"social","soft":["Silae","Portails OPS"],"f":"Mensuel","m":15},
  {"code":"contrats_travail","e":"saisie","l":"Contrats de travail et DPAE","d":"Contrat généré depuis le modèle du cabinet, DPAE déposée, signature électronique","t":"social","soft":["Silae","Yousign"],"f":"Mensuel","m":25},
  {"code":"solde_tout_compte","e":"cloture","l":"Soldes de tout compte et documents de fin de contrat","d":"Documents de fin de contrat établis, contrôlés et diffusés au salarié","t":"social","soft":["Silae"],"f":"Mensuel","m":30},
  {"code":"ag_annuelle","e":"cloture","l":"Approbation des comptes et assemblée annuelle","d":"Convocation, rapport de gestion, PV et dépôt préparés dossier par dossier","t":"juridique","soft":["Polyacte","Jesignexpert"],"f":"Annuel","m":60},
  {"code":"formalites_greffe","e":"cloture","l":"Formalités au guichet unique (INPI)","d":"Modifications statutaires, transferts de siège et changements de dirigeant déposés et suivis","t":"juridique","soft":["INPI","Infogreffe"],"f":"Mensuel","m":45},
  {"code":"benef_effectifs","e":"cloture","l":"Déclaration des bénéficiaires effectifs","d":"Déclaration établie et déposée à partir de la table de capitalisation","t":"juridique","soft":["INPI"],"f":"Annuel","m":30},
  {"code":"circularisation","e":"cloture","l":"Circularisation des tiers (audit)","d":"Demandes de confirmation envoyées, réponses rapprochées et écarts documentés","t":"compta","soft":["Caseware","Outlook"],"f":"Annuel","m":90},
  {"code":"feuilles_travail","e":"cloture","l":"Feuilles de travail d’audit et tests de détail","d":"Échantillons tirés, pièces rapprochées, feuilles de travail alimentées","t":"compta","soft":["Caseware","RévisAudit"],"f":"Annuel","m":120},
  {"code":"lm_renouvellement","e":"relation","l":"Renouvellement des lettres de mission et révision des honoraires","d":"Lettres mises à jour selon la grille tarifaire, envoyées en signature","t":"juridique","soft":["GED","Yousign"],"f":"Annuel","m":20},
  {"code":"prospects","e":"relation","l":"Qualification et suivi des prospects","d":"Fiche prospect enrichie, relances programmées, rendez-vous planifié","t":"com","soft":["CRM","Pappers"],"f":"Hebdomadaire","m":15},
  {"code":"newsletter","e":"cabinet","l":"Newsletter et actualités clients","d":"Actualités fiscales et sociales rédigées, mises en forme et diffusées à vos clients","t":"com","soft":["Brevo","Mailchimp"],"f":"Mensuel","m":240},
  {"code":"linkedin","e":"cabinet","l":"Page LinkedIn du cabinet","d":"Posts préparés à partir de l’actualité du cabinet, planifiés et suivis","t":"com","soft":["LinkedIn","Canva"],"f":"Hebdomadaire","m":60},
  {"code":"onboarding_collab","e":"cabinet","l":"Intégration d’un nouveau collaborateur","d":"Comptes créés, accès aux logiciels et à la GED, matériel et parcours d’intégration","t":"libre","soft":["Microsoft 365","Logiciels métier"],"f":"Mensuel","m":90},
  {"code":"entretiens","e":"cabinet","l":"Entretiens annuels et professionnels","d":"Convocations, trames pré-remplies et comptes rendus archivés","t":"libre","soft":["Lucca","GED"],"f":"Annuel","m":45},
  {"code":"formation_collab","e":"cabinet","l":"Plan de formation et obligations","d":"Suivi des heures de formation, inscriptions et attestations archivées","t":"libre","soft":["OPCO","GED"],"f":"Trimestriel","m":30},
  {"code":"acces_it","e":"cabinet","l":"Comptes, accès et sauvegardes informatiques","d":"Création et révocation des accès, mises à jour et contrôle des sauvegardes","t":"libre","soft":["Microsoft 365","Logiciels métier"],"f":"Hebdomadaire","m":30},
  {"code":"tickets_it","e":"cabinet","l":"Support informatique de premier niveau","d":"Demandes des collaborateurs qualifiées, résolues ou transmises au prestataire","t":"libre","soft":["Teams","Outil de tickets"],"f":"Quotidien","m":15},
  {"code":"rgpd","e":"cabinet","l":"Registre RGPD et demandes d’exercice de droits","d":"Registre des traitements tenu à jour, demandes traitées dans les délais","t":"juridique","soft":["GED","Outlook"],"f":"Mensuel","m":45},
  {"code":"tresorerie_cabinet","e":"cabinet","l":"Trésorerie du cabinet et rapprochement des encaissements","d":"Encaissements rapprochés des factures d’honoraires, prévision de trésorerie mise à jour","t":"libre","soft":["Banque","Logiciel de facturation"],"f":"Hebdomadaire","m":45},
  {"code":"avis_clients","e":"cabinet","l":"Avis clients et satisfaction","d":"Enquêtes envoyées après le bilan, réponses consolidées, avis publics sollicités","t":"com","soft":["Google","Outlook"],"f":"Trimestriel","m":20}
,
  {"code":"mails_collab","e":"cabinet","l":"Traitement des mails entrants (collaborateurs et boîtes partagées)","d":"Mails lus, classés et routés : réponse de premier niveau, pièce jointe en GED, demande transmise au bon collaborateur","t":"com","soft":["Outlook","Microsoft 365","Gmail"],"f":"Quotidien","m":5}
];
 var PROD={mails_collab:1,pieces:1,banque:1,od_paie:1,lettrage:1,tva:1,cloture:1,edi_flux:1,ir:1,paie_var:1,relances:1,ged:1,dsn:1};
 PROCS.sort(function(a,b){return (PROD[b.code]?1:0)-(PROD[a.code]?1:0)});
 function STAR(p){return PROD[p.code]?'<i class="fav" title="Pl\u00e9biscit\u00e9 par les cabinets">&#9733;</i> ':''}

 var LOG={
  social:['Silae','Cegid Quadra Paie','Sage Paie','ACD Paie','Openpaye','Isapaye'],
  compta:['Cegid Expert','Cegid Loop','Quadratus','Sage Génération Experts','ACD','Agiris ISACOMPTA','Pennylane','Tiime','MyUnisoft','EBP','Fulll','Inqom'],
  ged:['SharePoint','Google Drive','OneDrive','Zeendoc','Welyb','MyCompanyFiles'],
  com:['Outlook','Teams','Gmail','WhatsApp'],
  juridique:['Polyacte','SECIB','Juriactes','Jesignexpert','LegalPlace','Lefebvre Dalloz','Infogreffe','INPI / RNE'],
  libre:[]
 };
 var METIER={compta:'Comptabilité',social:'Social & paie',juridique:'Juridique',ged:'GED',com:'Relation client',libre:'GI'};
 var QLOG={social:'Votre logiciel de paie',compta:'Votre logiciel comptable',ged:'Votre GED',com:'Votre outil de communication',juridique:'Votre logiciel juridique',libre:'Le logiciel utilisé pour ce processus'};
 var FREQ=[['Quotidien',220],['Hebdomadaire',52],['Mensuel',12],['Trimestriel',4],['Annuel',1],['Ponctuel (une fois)',1]]; // occurrences par an (220 jours ouvrés) ; ponctuel = une seule fois
 var MIN=[['2 min',2],['5 min',5],['10 min',10],['15 min',15],['30 min',20],['30 min',30],['45 min',45],['1 h',60],['1 h 30',90],['2 h',120],['3 h',180],['4 h',240]];
 var S={screen:'proc',cur:null,items:[],email:'',consent:false,sending:false,etape:'all',metier:'all',q:''};
 var hist=[];
 function $(s,c){return (c||document).querySelector(s)}function $$(s,c){return [].slice.call((c||document).querySelectorAll(s))}
 function esc(x){return String(x).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
 function norm(x){return String(x).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'')}
 function fFactor(f){for(var i=0;i<FREQ.length;i++)if(FREQ[i][0]===f)return FREQ[i][1];return 12}
 function hAnItem(it){return it.dossiers*it.minutes*fFactor(it.frequence)/60} function hMois(it){return hAnItem(it)/12}
 function total(){var t=0;S.items.forEach(function(i){t+=hMois(i)});return Math.round(t)}
 function hAn(){var t=0;S.items.forEach(function(i){t+=hAnItem(i)});return Math.round(t)}
 function hPonct(){var t=0;S.items.forEach(function(i){if(i.frequence==='Ponctuel (une fois)')t+=hAnItem(i)});return Math.round(t)}
 function ponctTxt(){var p=hPonct();return p?' &mdash; dont <b>'+fmt(p)+' h</b> de projets ponctuels (migrations, reprises), gagn&eacute;es une fois':''} function etp(){return Math.round(hAn()/1500*10)/10} function fmt(n){return Number(n).toLocaleString('fr-FR')}
 var PERSO=['gmail.com','googlemail.com','hotmail.com','hotmail.fr','outlook.com','outlook.fr','live.com','live.fr','msn.com','yahoo.com','yahoo.fr','ymail.com','orange.fr','wanadoo.fr','free.fr','sfr.fr','neuf.fr','laposte.net','bbox.fr','numericable.fr','icloud.com','me.com','mac.com','protonmail.com','proton.me','gmx.fr','gmx.com','aol.com','yandex.com','mail.com'];
 function domaine(e){var m=/^[^@\s]+@([^@\s]+\.[^@\s]+)$/.exec(e);return m?m[1].toLowerCase():''}
 function perso(e){var d=domaine(e);return !!d&&PERSO.indexOf(d)>=0}
 function save(){try{localStorage.setItem('f456diag',JSON.stringify(S.items))}catch(e){}}
 function auto(ms){clearTimeout(S.t);S.t=setTimeout(function(){if(!$('#dgnext').disabled)next()},ms||260)}
 function crumb(){var n=S.items.length; if(['proc','logiciel','dossiers','frequence','temps'].indexOf(S.screen)>=0){var steps={proc:1,logiciel:2,dossiers:3,frequence:4,temps:5};return 'Processus n&deg;'+(n+1)+(S.cur&&S.cur.libelle&&S.screen!=='proc'?' &middot; '+esc(S.cur.libelle).slice(0,42):'')+' &middot; question <b>'+steps[S.screen]+'</b> / 5'} if(S.screen==='loop')return n+' processus d&eacute;crit'+(n>1?'s':''); if(S.screen==='email')return 'Derni&egrave;re &eacute;tape'; return ''}
 function prog(){var m={proc:10,logiciel:28,dossiers:46,frequence:64,temps:82,loop:90,email:96,merci:100};return m[S.screen]||0}
 function nav(txt,dis){$('#dgnext').textContent=txt;$('#dgnext').disabled=!!dis;}
 function uniq(a){var o=[],s={};a.forEach(function(x){if(x&&!s[x]){s[x]=1;o.push(x)}});return o}
 function renderProcs(){
  var box=$('#procs'),q=norm(S.q),h='',n=0;
  PROCS.forEach(function(p){
   if(S.items.some(function(i){return i.code===p.code}))return;
   if(S.etape!=='all'&&p.e!==S.etape)return; if(S.metier!=='all'&&p.t!==S.metier)return;
   if(q&&norm(p.l+' '+p.d+' '+p.soft.join(' ')).indexOf(q)<0)return;
   n++;h+='<div class="proc'+(S.cur&&S.cur.code===p.code?' sel':'')+'" data-c="'+p.code+'"><b>'+STAR(p)+esc(p.l)+'</b><span>'+esc(p.d)+'</span><em>'+(METIER[p.t]||'Cabinet')+'</em>'+(p.f==='Ponctuel (une fois)'?' <em class="pj">projet ponctuel</em>':'')+'<i class="roi">&asymp; '+p.m+' min par dossier &middot; '+(p.f==='Ponctuel (une fois)'?'une fois':p.f.toLowerCase())+'</i></div>';
  });
  if(!n)h='<div class="empty">Aucun processus standard ne correspond &mdash; d&eacute;crivez le v&ocirc;tre ci-dessous, nos agents codeurs d&eacute;veloppent le connecteur sur simple demande.</div>';
  box.innerHTML=h;
  $$('.proc',box).forEach(function(o){o.addEventListener('click',function(){$$('.proc',box).forEach(function(x){x.classList.remove('sel')});o.classList.add('sel');var p=PROCS.filter(function(x){return x.code===o.dataset.c})[0];S.cur={code:p.code,libelle:p.l,type:p.t,soft:p.soft,frequence:p.f,etape:p.e,minutes:p.m};$('#cust').value='';nav('Continuer →',false);});});
 }
 function render(){
  var b=$('#dgbody'),h='';
  $('#dgbar').style.width=prog()+'%';$('#dgcrumb').innerHTML=crumb();
  $('#dgprev').style.visibility=(hist.length&&S.screen!=='merci')?'visible':'hidden';
  $('#dgcount').textContent='';
  document.querySelector('.dg .nav').style.display=(S.screen==='merci')?'none':'flex';
  if(S.screen==='proc'){
   h+='<h3>'+(S.items.length?'Quel autre processus voulez-vous automatiser ?':'Quel processus voulez-vous automatiser ?')+'</h3><p class="hint">'+PROCS.length+' processus, des plus courants aux migrations &mdash; filtrez par m&eacute;tier et par &eacute;tape, ou cherchez un mot. Le temps par dossier est pr&eacute;-rempli d&rsquo;apr&egrave;s nos retours terrain.</p>';
   h+='<div class="search"><input type="text" id="q" autocomplete="off" placeholder="Rechercher : TVA, paie, relances, migration GED&hellip;" value="'+esc(S.q)+'"></div>';
   var MK=[['compta','Comptabilité'],['social','Social & paie'],['juridique','Juridique'],['ged','GED'],['com','Relation client'],['libre','GI']];
   h+='<div class="tabs" id="tabm"><span class="lbl">M&eacute;tier</span><div class="tab'+(S.metier==='all'?' on':'')+'" data-m="all">Tous</div>';
   MK.forEach(function(k){var c=PROCS.filter(function(p){return p.t===k[0]&&!S.items.some(function(i){return i.code===p.code})}).length;if(c)h+='<div class="tab'+(S.metier===k[0]?' on':'')+'" data-m="'+k[0]+'">'+k[1]+'<i>'+c+'</i></div>'});
   h+='</div><div class="tabs" id="tabs"><span class="lbl">&Eacute;tape</span><div class="tab'+(S.etape==='all'?' on':'')+'" data-e="all">Toutes</div>';
   ETAPES.forEach(function(e){var c=PROCS.filter(function(p){return p.e===e[0]&&!S.items.some(function(i){return i.code===p.code})}).length;if(c)h+='<div class="tab'+(S.etape===e[0]?' on':'')+'" data-e="'+e[0]+'">'+e[1]+'<i>'+c+'</i></div>'});
   h+='</div><div class="procs" id="procs"></div>';
   h+='<div class="addrow"><input type="text" id="cust" autocomplete="off" placeholder="Un autre processus ? D&eacute;crivez-le en quelques mots&hellip;"><button type="button" class="btn btn-ghost" id="custbtn" style="padding:11px 18px;font-size:13.5px">Utiliser</button></div>';
   b.innerHTML=h;nav('Continuer →',!(S.cur&&S.cur.code!=='libre'));
   renderProcs();
   $$('#tabs .tab').forEach(function(t){t.addEventListener('click',function(){S.etape=t.dataset.e;$$('#tabs .tab').forEach(function(x){x.classList.remove('on')});t.classList.add('on');renderProcs();});});
   $$('#tabm .tab').forEach(function(t){t.addEventListener('click',function(){S.metier=t.dataset.m;$$('#tabm .tab').forEach(function(x){x.classList.remove('on')});t.classList.add('on');renderProcs();});});
   $('#q').addEventListener('input',function(){S.q=this.value;renderProcs();});
   var useCust=function(){var v=$('#cust').value.trim();if(!v)return;S.cur={code:'libre',libelle:v,type:'libre',soft:[],frequence:'',etape:'libre'};next();};
   $('#custbtn').addEventListener('click',useCust);
   $('#cust').addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();useCust();}});
   $('#cust').addEventListener('input',function(){if(this.value.trim()){$$('#procs .proc').forEach(function(x){x.classList.remove('sel')});S.cur=null;nav('Continuer →',false);}else if(!$('#procs .proc.sel'))nav('Continuer →',true);});
  }
  else if(S.screen==='logiciel'){
   var list=uniq((S.cur.soft||[]).concat(LOG[S.cur.type]||[]));
   h+='<h3>'+QLOG[S.cur.type]+'</h3><p class="hint">Pour &laquo; '+esc(S.cur.libelle)+' &raquo;'+(S.cur.soft&&S.cur.soft.length?' &mdash; connecteurs d&eacute;j&agrave; en place en premier':'')+'</p>';
   h+='<div class="opts" id="o">';
   list.forEach(function(l){var first=(S.cur.soft||[]).indexOf(l)>=0;h+='<div class="opt'+(S.cur.logiciel===l?' sel':'')+'">'+esc(l)+'<small>'+(first?'connecteur en place':'connecteur disponible')+'</small></div>'});
   h+='<div class="opt'+(S.cur.logiciel&&list.indexOf(S.cur.logiciel)<0?' sel':'')+'">Autre<small>sur simple demande</small></div></div>';
   h+='<div class="addrow" id="lgrow" style="display:none"><input type="text" id="lg2" autocomplete="off" placeholder="Pr&eacute;cisez le logiciel&hellip;"></div>';
   b.innerHTML=h;nav('Continuer →',!S.cur.logiciel);
   $$('#o .opt').forEach(function(o){o.addEventListener('click',function(){$$('#o .opt').forEach(function(x){x.classList.remove('sel')});o.classList.add('sel');var val=o.childNodes[0].textContent.trim();var free=val==='Autre';$('#lgrow').style.display=free?'flex':'none';if(free){S.cur.logiciel='';$('#lg2').focus();nav('Continuer →',true);}else{S.cur.logiciel=val;nav('Continuer →',false);auto();}});});
   $('#lg2').addEventListener('input',function(){S.cur.logiciel=this.value.trim();nav('Continuer →',!S.cur.logiciel);});
  }
  else if(S.screen==='dossiers'){
   h+='<h3>Combien de dossiers sont concern&eacute;s ?</h3><p class="hint">Pour &laquo; '+esc(S.cur.libelle)+' &raquo;</p><div class="opts" id="o">';
   [100,250,500,1000,2500,5000,10000].forEach(function(n){h+='<div class="opt'+(S.cur.dossiers===n?' sel':'')+'" data-v="'+n+'">'+n.toLocaleString('fr-FR')+'</div>'});
   h+='</div><div class="addrow"><input type="number" id="nb" autocomplete="off" min="1" max="50000" placeholder="ou un nombre pr&eacute;cis&hellip;" value="'+(S.cur.dossiers&&[100,250,500,1000,2500,5000,10000].indexOf(S.cur.dossiers)<0?S.cur.dossiers:'')+'"></div>';
   b.innerHTML=h;nav('Continuer →',!(S.cur.dossiers>0));
   $$('#o .opt').forEach(function(o){o.addEventListener('click',function(){$$('#o .opt').forEach(function(x){x.classList.remove('sel')});o.classList.add('sel');S.cur.dossiers=+o.dataset.v;$('#nb').value='';nav('Continuer →',false);auto();});});
   $('#nb').addEventListener('input',function(){S.cur.dossiers=+this.value;$$('#o .opt').forEach(function(x){x.classList.remove('sel')});nav('Continuer →',!(S.cur.dossiers>0));});$('#nb').addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();if(!$('#dgnext').disabled)next();}});
  }
  else if(S.screen==='frequence'){
   h+='<h3>&Agrave; quelle fr&eacute;quence ?</h3><p class="hint">&laquo; '+esc(S.cur.libelle)+' &raquo; est trait&eacute;&hellip;'+(S.cur.frequence?' <span style="color:#7CE38B">(fr&eacute;quence habituelle pr&eacute;-s&eacute;lectionn&eacute;e)</span>':'')+'</p><div class="opts" id="o">';
   FREQ.forEach(function(f){h+='<div class="opt'+(S.cur.frequence===f[0]?' sel':'')+'">'+f[0]+'</div>'});h+='</div>';
   b.innerHTML=h;nav('Continuer →',!S.cur.frequence);
   $$('#o .opt').forEach(function(o){o.addEventListener('click',function(){$$('#o .opt').forEach(function(x){x.classList.remove('sel')});o.classList.add('sel');S.cur.frequence=o.textContent.trim();nav('Continuer →',false);auto();});});
  }
  else if(S.screen==='temps'){
   h+='<h3>Temps pass&eacute; par dossier ?</h3><p class="hint">&Agrave; chaque occurrence, pour un dossier'+(S.cur.minutes&&S.cur.code!=='libre'?' &mdash; <span style="color:#7CE38B">temps habituel pr&eacute;-rempli d&rsquo;apr&egrave;s nos retours terrain, ajustez-le &agrave; votre cabinet</span>':' &mdash; le processus s&rsquo;ajoute automatiquement')+'</p><div class="opts" id="o">';
   MIN.forEach(function(m){h+='<div class="opt'+(S.cur.minutes===m[1]?' sel':'')+'" data-v="'+m[1]+'">'+m[0]+'</div>'});h+='</div><div class="estline" id="est"></div>';
   b.innerHTML=h;nav('Ajouter ce processus →',!S.cur.minutes);
   var est=function(){if(S.cur.minutes){$('#est').innerHTML=(S.cur.frequence==='Ponctuel (une fois)')?'Soit environ <b>'+fmt(Math.round(hAnItem(S.cur)))+' h, une seule fois</b> sur ce projet':'Soit environ <b>'+fmt(Math.round(hAnItem(S.cur)))+' h par an</b> sur ce processus ('+fmt(Math.round(hMois(S.cur)*10)/10)+' h par mois)'}};est();
   $$('#o .opt').forEach(function(o){o.addEventListener('click',function(){$$('#o .opt').forEach(function(x){x.classList.remove('sel')});o.classList.add('sel');S.cur.minutes=+o.dataset.v;est();nav('Ajouter ce processus →',false);auto(700);});});
  }
  else if(S.screen==='loop'){
   h+='<h3>Vos processus</h3><p class="hint">Ajoutez-en un autre, ou passez &agrave; la derni&egrave;re &eacute;tape</p>';
   S.items.forEach(function(it,i){h+='<div class="done"><span>'+esc(it.libelle)+'<small>'+esc(it.logiciel)+' &middot; '+fmt(it.dossiers)+' dossiers &middot; '+it.minutes+' min &middot; '+(it.frequence==='Ponctuel (une fois)'?'projet ponctuel':it.frequence.toLowerCase())+'</small></span><span><b>'+fmt(Math.round(hAnItem(it)))+(it.frequence==='Ponctuel (une fois)'?' h, une fois':' h/an')+'</b><span class="rm" data-i="'+i+'">retirer</span></span></div>'});
   h+='<div class="estline">Total : <b>'+fmt(hAn())+' h par an</b> ('+fmt(total())+' h par mois), soit <b>'+fmt(etp())+' ETP</b> sur une base de 1&nbsp;500 h/an'+ponctTxt()+'</div>';
   h+='<div class="nav" style="margin-top:18px;justify-content:flex-start"><button type="button" class="btn btn-ghost" id="more">+ Ajouter un autre processus</button></div>';
   b.innerHTML=h;nav('Terminer →',S.items.length===0);
   $('#more').addEventListener('click',function(){S.cur=null;S.q='';S.etape='all';S.metier='all';go('proc');});
   $$('.rm').forEach(function(r){r.addEventListener('click',function(){S.items.splice(+r.dataset.i,1);save();render();});});
  }
  else if(S.screen==='email'){
   h+='<div class="ok-badge">&#10003; Diagnostic complet</div><h3>Recevez votre cotation</h3>';
   h+='<div class="bigsum"><div class="b"><b>'+fmt(hAn())+' h</b><span>par an, selon vos temps par dossier ('+fmt(total())+' h par mois)</span></div><div class="b"><b>'+fmt(etp())+' ETP</b><span>&eacute;quivalent temps plein, base 1&nbsp;500 h/an</span></div><div class="b"><b>'+S.items.length+'</b><span>processus &agrave; confier aux agents RunBot</span></div></div>'+(hPonct()?'<p class="hint" style="margin-top:-8px">Dont '+fmt(hPonct())+' h de projets ponctuels (migrations, reprises), gagn&eacute;es une seule fois.</p>':'');
   h+='<p class="hint">Elle est &eacute;tablie par Factory 456 sur la base de vos r&eacute;ponses et vous est adress&eacute;e par e-mail.</p>';
   h+='<label class="fl">Votre e-mail professionnel</label><input type="email" id="mail" autocomplete="email" placeholder="vous@cabinet.fr" value="'+esc(S.email)+'"><div class="hint" id="cab" style="margin:8px 0 0;min-height:18px"></div>';
   h+='<label class="consent"><input type="checkbox" id="ok"'+(S.consent?' checked':'')+'> J&rsquo;accepte que Factory 456 utilise ces informations pour &eacute;tablir ma cotation et me recontacter. Aucune communication &agrave; des tiers. <a href="/donnees-personnelles" style="color:#C6A467">Donn&eacute;es personnelles</a></label>';
   h+='<div class="err" id="err"></div>';
   b.innerHTML=h;
   var ck=function(){S.email=$('#mail').value.trim();S.consent=$('#ok').checked;var ok=/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(S.email);var c=$('#cab');if(ok&&perso(S.email)){c.innerHTML='<span style="color:#FF9B8F">Merci d&rsquo;indiquer votre adresse professionnelle : elle nous permet d&rsquo;identifier votre cabinet.</span>';ok=false;}else if(ok){c.innerHTML='Cabinet identifi&eacute; : <b style="color:#7CE38B">'+esc(domaine(S.email))+'</b>';}else c.innerHTML='';nav('Recevoir ma cotation →',!(ok&&S.consent));};
   $('#mail').addEventListener('input',ck);$('#ok').addEventListener('change',ck);ck();$('#mail').focus();$('#mail').addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();ck();if(!$('#dgnext').disabled)next();}});
  }
  else if(S.screen==='merci'){
   h+='<div style="text-align:center;padding:16px 0"><div class="ok-badge">&#10003; Demande envoy&eacute;e</div><h3>Merci !</h3><p class="hint" style="font-size:15px">Votre diagnostic ('+S.items.length+' processus, '+fmt(hAn())+' h par an, soit '+fmt(etp())+' ETP) est entre les mains de l&rsquo;&eacute;quipe Factory 456.<br>Vous recevrez votre cotation personnalis&eacute;e <b style="color:#FAAF31">sous 4&nbsp;h ouvr&eacute;es</b>.</p><p style="margin-top:22px"><a class="btn btn-gold" href="/runbot">D&eacute;couvrir la plateforme RunBot</a></p></div>';
   b.innerHTML=h;
  }
  window.scrollTo({top:document.querySelector('.dg').offsetTop-120,behavior:'smooth'});
 }
 function go(s){hist.push({screen:S.screen,cur:S.cur?JSON.parse(JSON.stringify(S.cur)):null});S.screen=s;render();}
 function next(){
  if(S.screen==='proc'){var v=$('#cust')&&$('#cust').value.trim();if(v){S.cur={code:'libre',libelle:v,type:'libre',soft:[],frequence:'',etape:'libre'};}if(!S.cur)return;go('logiciel');}
  else if(S.screen==='logiciel'){go('dossiers');}
  else if(S.screen==='dossiers'){go('frequence');}
  else if(S.screen==='frequence'){go('temps');}
  else if(S.screen==='temps'){S.items.push(S.cur);S.cur=null;save();go('loop');}
  else if(S.screen==='loop'){go('email');}
  else if(S.screen==='email'){send();}
 }
 $('#dgnext').addEventListener('click',next);
 $('#dgprev').addEventListener('click',function(){var p=hist.pop();if(!p)return;if(S.screen==='loop'&&p.screen==='temps'){S.cur=S.items.pop();}else if(p.cur&&!S.cur){S.cur=p.cur;}S.screen=p.screen;render();});
 function send(){
  if(S.sending)return;S.sending=true;nav('Envoi…',true);
  var payload={cabinet:{dossiers:Math.max.apply(null,S.items.map(function(i){return i.dossiers}))},
   logiciels:{compta:(S.items.filter(function(i){return i.type==='compta'})[0]||{}).logiciel||'',paie:(S.items.filter(function(i){return i.type==='social'})[0]||{}).logiciel||'',ged:S.items.filter(function(i){return i.type==='ged'}).map(function(i){return i.logiciel})},
   processus:S.items.map(function(i){return {code:i.code,libelle:i.libelle+(i.etape&&i.etape!=='libre'?' ['+i.etape+']':''),logiciel:i.logiciel,dossiers:i.dossiers,minutes:i.minutes,frequence:i.frequence,heures_mois:Math.round(hMois(i)*10)/10,heures_an:Math.round(hAnItem(i))}}),
   priorite:S.items[0]?S.items[0].libelle:'',pa:'',commentaire:'',
   contact:{nom:'',cabinet:S.email.split('@')[1]||'',email:S.email,tel:''},consent:true,total_heures:total(),total_heures_an:hAn(),etp:etp(),source:document.referrer||'direct',website:$('#dghp').value};
  fetch('/wp-json/f456/v1/diagnostic',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)})
  .then(function(r){return r.json().then(function(j){return {s:r.status,j:j}})})
  .then(function(x){if(x.s===200&&x.j&&x.j.ok){try{localStorage.removeItem('f456diag')}catch(e){}S.screen='merci';render();}else{throw new Error((x.j&&x.j.message)||'erreur')}})
  .catch(function(e){S.sending=false;var er=$('#err');if(er){er.textContent='Envoi impossible ('+e.message+'). Réessayez ou écrivez-nous via la page contact.';er.style.display='block';}nav('Recevoir ma cotation →',false);});
 }
 try{var saved=JSON.parse(localStorage.getItem('f456diag')||'[]');if(saved.length){S.items=saved;S.screen='loop';}}catch(e){}
 render();
})();
